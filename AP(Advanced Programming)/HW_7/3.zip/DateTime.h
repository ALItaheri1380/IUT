#pragma once
#include <iostream>
#include <assert.h>
#include <string>
#include "Data.h"
#include "Time.h"
using namespace std;
class DateTime :public Data,public Time {
public:
    
    DateTime( int y_=2022 , int m_=5 , int d_=3 , int h1=11 , int m1=30);
    operator string();
    string Compare(DateTime data) const;
    friend istream& operator >> (istream& in, DateTime& data);
    friend ostream& operator << ( ostream& out,DateTime& data);
    friend bool operator < (const DateTime& op1,const  DateTime& op2);
    friend bool operator >= (const DateTime& op1,const DateTime& op2);
    friend bool operator > (const DateTime& op1,const  DateTime& op2);
    friend bool operator <= (const DateTime& op1,const DateTime& op2);
    friend DateTime operator + ( DateTime& op1, DateTime& op2);
};