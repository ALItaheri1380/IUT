#pragma once
#include<iostream>
#include"DateTime.h"
using namespace std;
int main() {
    DateTime d1;
    cin >> d1;
    cout << d1 << endl;
    cout << "-++-+--+-+-+-+-+-+-+-+-+-+-++\n";
    DateTime d2;
    cin >> d2;
    cout << d2 << endl;
    cout << "-++-+--+-+-+-+-+-+-+-+-+-+-++\n";
    DateTime d3;
    d3 = d1 + d2;
    cout << string (d3) << endl;
    cout << boolalpha << (d1 <= d2);
}