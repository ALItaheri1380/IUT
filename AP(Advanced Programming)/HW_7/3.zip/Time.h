#pragma once
#include <iostream>
#include <string>
using namespace std;
class Time {
protected:
    int h;
    int m;
public:
    Time(int h1 = 0, int m1 = 0);
    Time(int h1);
    void setter(int h1, int m1);
    void set_h(int h1);
    void set_m(int m1);
    string get_h();
    string get_m();
    string get_h_m();
    string compear(Time x);
    string what_time();
    operator string();
    friend bool operator> (const Time& op1, const Time& op2);
    friend bool operator>= (const Time& op1, const Time& op2);
    friend bool operator<= (const Time& op1, const Time& op2);
    friend bool operator< (const Time& op1, const Time& op2);
    friend Time operator+(Time& op1, Time& op2);
    friend ostream& operator << (ostream& out, Time& time_);
    friend istream& operator >> (istream& in, Time& time_);
};