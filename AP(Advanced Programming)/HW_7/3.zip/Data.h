#pragma once
#include <iostream>
#include <string>
using namespace std;
class Data {
protected:
    int year;
    int month;
    int day;
public:
    Data(int year_=2022,int month_=4,int day_=29);
    void set_day(int d);
    void set_month(int m);
    void set_year(int y);
    int get_day();
    int get_month();
    int get_year();
    string compare(Data& data);
    int set_all(int y_,int m_,int d_);
    friend istream& operator >> (istream& in, Data& data);
    friend ostream& operator << (ostream& out, Data& data);
    friend bool operator> (const Data& op1, const Data& op2);
    friend Data operator + (const Data& op1, const Data& op2);
    friend bool operator>= (const Data& op1, const Data& op2);
    friend bool operator<= (const Data& op1, const Data& op2);
    operator string();
    friend bool operator< (const Data& op1, const Data& op2);
};