#pragma once
#include<iostream>
#include"Data.h"
#include"Time.h"
#include"DateTime.h"
using namespace std;
DateTime::DateTime(int y_,int m_ , int d_ ,int h1 , int m1){
    year=y_;
    month=m_;
    day=d_;
    h=h1;
    m=m1;
}
DateTime::operator string() {
    string tmp;
    string tmp2;
    string m2;
    string h2;
    if (h < 10) {
        h2 = '0';
        h2 += to_string(h);
    }
    else {
        h2 = to_string(h);
    }
    if (m < 10) {
        m2 += '0';
        m2 += to_string(m);
    }
    else {
        m2 = to_string(m);
    }
    if (day < 10) {
        tmp = '0';
        tmp += to_string(day);
    }
    else {
        tmp = to_string(day);
    }
    if (month < 10) {
        tmp2 = '0';
        tmp2 += to_string(month);
    }
    else {
        tmp2 = to_string(month);
    }

    return tmp2 + "/" + tmp + "/" + to_string(year) + " ||  AND TIME IS = " + h2 + " : " + m2;
}
string DateTime::Compare(DateTime data) const {
    if(data.year<year)
        return "smaler";
    else if(data.year==year){
        if(data.month<month)
            return "smaler";
        else if(data.month==month){
            if(data.day<day)
                return "smaler";
            else if(data.day==day) {
                if(data.h<h)
                    return "smaler";
                else if(data.h==h){
                    if(data.m<m)
                        return "smaler";
                    else if(data.m==m)
                        return "same";
                    else
                        return "biger";
                } else
                   return "biger";
            }
            else
                return  "biger";
        } else
            return "biger";
    } else
        return "biger";
}
istream& operator >> (istream& in, DateTime& data) {
    int year_,month_,day_,h_,m_;
    cout << "Enter YEAR\n";
    in >> year_;
    cout << "Enter MONTH \n";
    in >> month_;
    cout << "Enter DAY\n";
    in >> day_;
    cout << "ENTER HOURE\n";
    in >> h_;
    cout << "ENTER MIN\n";
    in >> m_;
    //****************************//
    assert((month_ <= 12 && month_ >= 1));
    assert((day_ >= 1 && day_ <= 31));
    if (m_ >= 60)
        m_=59;
    if(m_<0)
        m_=0;    
    if (h_ >= 24)
        h_=23;
    if(h_<0)
        h_=0;    
    data.set_all(year_,month_,day_);
    data.setter(h_,m_);    
    return in;
}
ostream& operator << (ostream& out,DateTime& data) {
     out<< string(data) +"|| TIME OF DAY IS =  "<<data.what_time();
    return out;
}
bool operator < (const DateTime& op1,const DateTime& op2) {
    if(op1.Compare(op2)=="biger")
        return true;
    else
        return false;
}
bool operator >= (const DateTime& op1,const DateTime& op2) {
    if(op1.Compare(op2)=="smaler"||op1.Compare(op2)=="same")
        return true;
    else
        return false;
}
bool operator > (const DateTime& op1,const DateTime& op2) {
    if(op1.Compare(op2)=="smaler")
        return true;
    else
        return false;
}
bool operator <= (const DateTime& op1,const  DateTime& op2) {
     if(op1.Compare(op2)=="biger"||op1.Compare(op2)=="same")
         return true;
     else
         return false;
}
DateTime operator + ( DateTime& op1,  DateTime& op2) {
    DateTime temp;
    int year_,month_,day_,m_,h_;
    int chek = 0;
    int chek2 = 0;
    year_ = op1.year + op2.year;
    month_ = op1.month + op2.month;
    day_ = op1.day + op2.day;
    if (op1.h + op2.h >= 24)
    {
        h_ = (op1.h + op2.h) % 24;
        if (op1.m + op2.m >= 60) {
            m_ = (op1.m + op2.m) % 60;
            h_++;
        }
        else
            m_ = (op1.m + op2.m);
            chek++;
            day_++;
    }
    if (op1.m + op2.m >= 60 && chek == 0) {
        h_ = op1.h + op2.h;
        m_ = (op1.m + op2.m) % 60;
        h_++;
        if(h_>=24){
            h_%=24;
            day_++;
        }
        chek2++;
    }
    if (day_ > 31){
        if(day_%31==0){
            day_=31;
            month_++;
        }
        else{
            day_ %= 31;
            month_++;
        }
    }
    if (month_ > 12){
         if(month_%12==0){
            month_=12;
            year_++;
        }
        else{
            month_ %= 12;
            year_++;
        }
    }
    if (chek2 == 0 && chek == 0) {
        h_ = op1.h + op2.h;
        m_ = op1.m + op2.m;
    }
    temp.set_all(year_,month_,day_);
    temp.setter(h_,m_);
    return temp;
}