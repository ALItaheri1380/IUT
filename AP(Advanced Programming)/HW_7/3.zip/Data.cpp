#pragma once
#include<iostream>
#include <string>
#include "Data.h"
#include "Time.h"
using namespace std;
Data::Data(int year_,int month_,int day_){
    year=year_;
    month=month_;
    day=day_;
}
void Data::set_day(int d){
    day=d;
}
void Data::set_month(int m){
    month=m;
}
void Data::set_year(int y){
    year=y;
}
int Data::get_day(){
    return day;
}
int Data::get_month(){
    return month;
}
int Data::get_year(){
    return year;
}
int Data::set_all(int y_,int m_,int d_){
    year=y_;
    month=m_;
    day=d_;
}
string Data::compare(Data& data){
     if(data.year<year)
         return "smaler";
     else if(data.year==year){
         if(data.month<month)
             return "smaler";
         else if(data.month==month){
             if(data.day<day)
                 return "smaler";
             else if(data.day==day)
                 return "same";
             else
                 return  "biger";
         } else
             return "biger";
     } else
         return "biger";
}
Data::operator string() {
    string tmp;
    string tmp2;
    if (day < 10) {
        tmp = '0';
        tmp += to_string(day);
    }
    else {
        tmp = to_string(day);
    }
    if (month < 10) {
        tmp2 = '0';
        tmp2 += to_string(month);
    }
    else {
        tmp2 = to_string(month);
    }
    return tmp2 + "/" + tmp + "/" + to_string(year);
}
istream& operator >> (istream& in, Data& data) {
    cout << "Enter YEAR\n";
    in >> data.year;
    cout << "Enter MONTH \n";
    in >> data.month;
    cout << "Enter DAY\n";
    in >> data.day;
    if(data.day>31){
        if(data.day%31==0){
           data.day=31;
           data.month++;
        }
        else
        {     
            data.day%=31;
            data.month++;
        }
    }
    if(data.month>12){
        if(data.month%12==0){
            data.month=12;
            data.year++;
        }
        else{    
            data.month%=12;
            data.year++;
        }
    }
    return in;
}
ostream& operator << (ostream& out, Data& data) {
    out << string(data);
    return out;
}
bool operator> (const Data& op1, const Data& op2) {
    if (op1.year > op2.year)
        return true;
    else if (op1.year == op2.year) {
        if (op1.month > op2.month)
            return true;
        else if (op1.month == op2.month) {
            if (op1.day > op2.day)
                return true;
            else
                return false;
        }
        else
            return false;
    }
    else
        return false;
}
Data operator + (const Data& op1, const Data& op2) {
    Data temp;
    temp.year = op1.year + op2.year;
    temp.month = op1.month + op2.month;
    temp.day = op1.day + op2.day;
    if (temp.day > 31){
        if(temp.day%31==0){
            temp.day=31;
            temp.month++;
        }
        else{    
            temp.day %= 31;
            temp.month++;
        }
    }
    if (temp.month > 12){
        if(temp.month%12==0){
           temp.month=12;
           temp.year++;
        }
        else{   
           temp.month %= 12;
           temp.year++;
        }
    }
    return temp;
}
bool operator>= (const Data& op1, const Data& op2) {
    if (op1.year > op2.year)
        return true;
    else if (op1.year == op2.year) {
        if (op1.month > op2.month)
            return true;
        else if (op1.month == op2.month) {
            if (op1.day >= op2.day)
                return true;
            else
                return false;
        }
        else
            return false;
    }
    else
        return false;
}
bool operator<= (const Data& op1, const Data& op2) {
    if (op1.year < op2.year)
        return true;
    else if (op1.year == op2.year) {
        if (op1.month < op2.month)
            return true;
        else if (op1.month == op2.month) {
            if (op1.day <= op2.day)
                return true;
            else
                return false;
        }
        else
            return false;
    }
    else
        return false;
}
bool operator< (const Data& op1, const Data& op2) {
    if (op1.year < op2.year)
        return true;
    else if (op1.year == op2.year) {
        if (op1.month < op2.month)
            return true;
        else if (op1.month == op2.month) {
            if (op1.day < op2.day)
                return true;
            else
                return false;
        }
        else
            return false;
    }
    else
        return false;
}