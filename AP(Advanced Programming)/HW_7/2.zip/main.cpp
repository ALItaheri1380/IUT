#include<iostream>
#include"op.h"
using namespace std;
int main(){
    op p;
    op p2;
    op p3;
    op p4;
    cin>>p;
    cin>>p2;
    p3=(p*p2);
    p4 = p/p2;
    op p6= p + p2;
    op p5 = p - p2;
    cout <<"the multi is = "<< p3 << endl;
    cout << "div is = "<< p4 << endl;
    cout <<"the subtract is = " << p5 << endl;
    cout<<"the sum is = "<<p6<<endl;

}  
