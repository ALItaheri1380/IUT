#include<iostream>
#include <string>
#include <sstream>
#include <algorithm>
#include"vactor.h"
using namespace std;
class op:vactor<int>{
private:
    vactor<int>* myvec=new vactor<int>;    
public:
    //---------------------------------------------------------------------------------------//
   op(string temp="10");
   friend op operator+(const op& op1,const op& op2);
   op &operator -= (op& op2);
   friend op operator - (const op& op1,const op& op2);
   op operator / (const op& op2);
   op &operator /= (op& op2);
   op operator * (const op& op2);
   op &operator *= ( op& op2);
   op &operator += (op& op2);
   friend bool operator < (op& op1,op& op2);
   friend bool operator <= (op& op1,op& op2);
   friend bool operator >= (op& op1,op& op2);
   friend bool operator >(op& op1,op& op2);
   static ostringstream F(string a,string b);
   friend istream& operator >> (istream& in,op& op1);
   friend ostream& operator << (ostream& out, op& op1);
//*************************************************************************************************//
   static bool Compare(string first,string second);
   static string fun(string num1,string num2);
};
