#include<iostream>
#include"op.h"
op::op(string temp){
    if(temp[0]=='-'){
        myvec->push_back(-1*int(temp[1]-'0'));
        for (int i = 2; i < temp.size(); i++)
            myvec->push_back(int(temp[i]-'0'));
    }
    else
        for (int i = 0; i < temp.size(); i++)
            myvec->push_back(int(temp[i]-'0'));
}
istream& operator >> (istream& in,op& op1){
     string x;
        int check=0;
        in>>x;
        op1.myvec->deleteList();
       if(x[0]=='-') {
           op1.myvec->push_back(-1 * int(x[1] - '0'));
           check=1;
        }
       if(check==1){
        for (int i = 2; i < x.size(); ++i) {
               op1.myvec->push_back(int(x[i])-'0');
            }
       } else{
           for (int i = 0; i < x.size(); ++i)
               op1.myvec->push_back(int(x[i])-'0');
       }
        return in;
}
ostream& operator << (ostream& out, op& op1) {
    for (int i = 0; i < op1.myvec->SIze(); i++)
    {
        out<<op1.myvec->searchdata(i);
    }
    return out;
}
bool op::Compare(string first,string second)
{
    int len1=first.size();
    int len2=second.size();
    if(len1<len2)
        return false;
    else if(len1==len2 && first<second)
        return false;
    return true;
}

bool operator <(op& op1,op& op2){
   int n1 = op1.myvec->SIze(), n2 = op2.myvec->SIze();
   if(op1.myvec->searchdata(0)>0 && op2.myvec->searchdata(0)>0){
        if (n1 < n2)
            return true;
        if (n1 > n2)
            return false;
    
    for (int i=0; i<n1; i++)
    {
        if (op1.myvec->searchdata(i) < op2.myvec->searchdata(i))
            return true;
        else if (op1.myvec->searchdata(i) > op1.myvec->searchdata(i))
            return false;
    }
    return false;
   }
    else if(op1.myvec->searchdata(0)<0 && op2.myvec->searchdata(0)>0)
        return true;
    else if(op1.myvec->searchdata(0)>0 && op2.myvec->searchdata(0)<0)
        return false;
    else
    {
        if (n1 < n2)
            return false;
        if (n1 > n2)
            return true;
    for (int i=0; i<n1; i++)
    {
        if (op1.myvec->searchdata(i) < op2.myvec->searchdata(i))
            return false;
        else if (op1.myvec->searchdata(i) > op1.myvec->searchdata(i))
            return true;
    }
    return false;
    }    
}
bool operator<=(op& op1,op& op2){
   int n1 = op1.myvec->SIze(), n2 = op2.myvec->SIze();
   if(op1.myvec->searchdata(0)>0 && op2.myvec->searchdata(0)>0){
        if (n1 < n2)
            return true;
        if (n1 > n2)
            return false;
    
    for (int i=0; i<n1; i++)
    {
        if (op1.myvec->searchdata(i) < op2.myvec->searchdata(i))
            return true;
        else if (op1.myvec->searchdata(i) > op1.myvec->searchdata(i))
            return false;
    }
    return true;
   }
    else if(op1.myvec->searchdata(0)<0 && op2.myvec->searchdata(0)>0)
        return true;
    else if(op1.myvec->searchdata(0)>0 && op2.myvec->searchdata(0)<0)
        return false;
    else
    {
        if (n1 < n2)
            return false;
        if (n1 > n2)
            return true;
    for (int i=0; i<n1; i++)
    {
        if (op1.myvec->searchdata(i) < op2.myvec->searchdata(i))
            return false;
        else if (op1.myvec->searchdata(i) > op1.myvec->searchdata(i))
            return true;
    }
    return true;
    }    
}
bool operator>=(op& op1,op& op2){
    int n1 = op1.myvec->SIze(), n2 = op2.myvec->SIze();
   if(op1.myvec->searchdata(0)>0 && op2.myvec->searchdata(0)>0){
        if (n1 > n2)
            return true;
        if (n1 < n2)
            return false;
    
    for (int i=0; i<n1; i++)
    {
        if (op1.myvec->searchdata(i) > op2.myvec->searchdata(i))
            return true;
        else if (op1.myvec->searchdata(i) < op1.myvec->searchdata(i))
            return false;
    }
    return true;
   }
    else if(op1.myvec->searchdata(0)<0 && op2.myvec->searchdata(0)>0)
        return false;
    else if(op1.myvec->searchdata(0)>0 && op2.myvec->searchdata(0)<0)
        return true;
    else
    {
        if (n1 > n2)
            return false;
        if (n1 < n2)
            return true;
    for (int i=0; i<n1; i++)
    {
        if (op1.myvec->searchdata(i) > op2.myvec->searchdata(i))
            return false;
        else if (op1.myvec->searchdata(i) < op1.myvec->searchdata(i))
            return true;
    }
    return true;
    }    
}
bool operator > (op& op1,op& op2){
    int n1 = op1.myvec->SIze(), n2 = op2.myvec->SIze();
   if(op1.myvec->searchdata(0)>0 && op2.myvec->searchdata(0)>0){
        if (n1 > n2)
            return true;
        if (n1 < n2)
            return false;
    
    for (int i=0; i<n1; i++)
    {
        if (op1.myvec->searchdata(i) > op2.myvec->searchdata(i))
            return true;
        else if (op1.myvec->searchdata(i) < op1.myvec->searchdata(i))
            return false;
    }
    return false;
   }
    else if(op1.myvec->searchdata(0)<0 && op2.myvec->searchdata(0)>0)
        return false;
    else if(op1.myvec->searchdata(0)>0 && op2.myvec->searchdata(0)<0)
        return true;
    else
    {
        if (n1 > n2)
            return false;
        if (n1 < n2)
            return true;
    for (int i=0; i<n1; i++)
    {
        if (op1.myvec->searchdata(i) > op2.myvec->searchdata(i))
            return false;
        else if (op1.myvec->searchdata(i) < op1.myvec->searchdata(i))
            return true;
    }
    return false;
    }    
}
bool SAME(string str1, string str2)
{
    int n1 = str1.length(), n2 = str2.length();
 
    if (n1 < n2)
        return true;
    if (n1 > n2)
        return false;
 
    for (int i=0; i<n1; i++)
    {
        if (str1[i] < str2[i])
            return true;
        else if (str1[i] > str2[i])
            return false;
    }
    return false;
}
op operator +(const op& op1,const op& op2){
    op tt;
    tt.myvec->deleteList();
    string tmp1;
    string final;
    string tmp2;
    string tmp2_;
    string tmp1_;
    int check_op1=1;
    int check_op2=1;
    int b=0;
    bool check_;
    int len=op1.myvec->SIze();
    int len2=op2.myvec->SIze();
    for (int i = 0; i < len2; ++i)
        tmp2+= to_string(op2.myvec->searchdata(i));
    for (int i = 0; i <len ; ++i)
        tmp1+=to_string(op1.myvec->searchdata(i));

    if(tmp1[0]=='-'){
        for (int i = 1; i < tmp1.size(); i++)
        {
            tmp1_+=tmp1[i];
            check_op1=0;
        }
    } else{
        for (int i = 0; i < tmp1.size(); i++)
            tmp1_+=tmp1[i];
    }
    if(tmp2[0]=='-'){
        for (int i = 1; i < tmp2.size(); i++)
        {
            tmp2_+=tmp2[i];
            check_op2=0;
        }
    } else{
        for (int i = 0; i < tmp2.size(); i++)
            tmp2_+=tmp2[i];
    }
    string str1=tmp1_;
    string str2=tmp2_;
    if(tmp1_==tmp2_){
        if(check_op1==0 || check_op2 ==0){
            if(check_op1==0 && check_op2==0){}
            else {
               tt.myvec->push_back(0);
                return tt;
            }
        }
    }
    if(check_op1==0||check_op2==0){
        if(check_op1==0&&check_op2==0)
            b=1;
        else
        {
            if(check_op1==0){
                check_=SAME(str1,str2);
                op1.myvec->reassign(0,-1*op1.myvec->searchdata(0));
                op gg=op1 - op2;
                op1.myvec->reassign(0,-1*op1.myvec->searchdata(0));
                string t;
                if(gg.myvec->searchdata(0)<0){
                    for (int i = 0; i < gg.myvec->SIze(); ++i) {
                        if(i==0)
                            gg.myvec->reassign(0,-1*gg.myvec->searchdata(0));
                            t += to_string(gg.myvec->searchdata(i));
                    }
                    //reverse(t.begin(), t.end());
                    final=t;
                } else{
                    for (int i = 0; i < gg.myvec->SIze(); ++i) {
                        final+= to_string(int(gg.myvec->searchdata(i)));
                    }
                }
                if(check_== false){
                    string ff="-";
                    for (int i = 0; i < final.size(); ++i) {
                        ff+=final[i];
                    }
                    tt.myvec->deleteList();
                    tt.myvec->push_back(-1*int(ff[1]-'0'));
                    for (int i = 2; i < ff.size(); ++i)
                        tt.myvec->push_back(int(ff[i]-'0'));
                    return tt;
                }else{
                    tt.myvec->deleteList();
                    for (int i = 0; i < final.size(); ++i) {
                        tt.myvec->push_back(int(final[i]-'0'));
                    }
                    return tt;}
            }
            else
            {
                op2.myvec->reassign(0,-1*op2.myvec->searchdata(0));
                op gg=op1-op2;
                op2.myvec->reassign(0,-1*op2.myvec->searchdata(0));
                string t;
                if(gg.myvec->searchdata(0)<0){
                    for (int i = 0; i < gg.myvec->SIze(); ++i) {
                        if(i==0)
                            gg.myvec->reassign(0,-1*gg.myvec->searchdata(0));
                            t += to_string(gg.myvec->searchdata(i));
                    }
                   // reverse(t.begin(), t.end());
                    final=t;
                }
                check_=SAME(str1,str2);
                if(check_==false){
                    return gg;
                }
                else{
//                    string r="-";
//                    for (int i = 0; i < final.size(); ++i)
//                        r+=final[i];
                    tt.myvec->deleteList();
                    tt.myvec->push_back(-1*int(final[0]-'0'));
                    for (int i = 1; i < final.size(); ++i)
                        tt.myvec->push_back(int(final[i]-'0'));
                    return tt;
                }
            }
        }
    }
    op p1;
    op p2;
    op p3;
    p1.myvec->deleteList();
    p2.myvec->deleteList();
    p3.myvec->deleteList();
    for (int i = 0; i < str1.size(); i++)
        p1.myvec->push_front(int(str1[i]-'0'));
    for (int i = 0; i < str2.size(); i++)
    {
        p2.myvec->push_front(int(str2[i]-'0'));
    }
    int s3;
    int lenn;
    string str;
    if(p1.myvec->SIze()>p2.myvec->SIze())
        lenn=p2.myvec->SIze();
    else
        lenn=p1.myvec->SIze();
    if(p1.myvec->SIze()>p2.myvec->SIze()) {
        for (int i = 0; i < lenn; i++) {
             {
                int s = p1.myvec->searchdata(i) + p2.myvec->searchdata(i);
                int s2 = s % 10;
                s3 = s / 10;
                p3.myvec->push_front(s2);
                p1.myvec->reassign(i + 1, s3 + p1.myvec->searchdata(i + 1));
             }
        }
    } else if(op1.myvec->SIze()==op2.myvec->SIze()){
        for (int i = 0; i < lenn; i++) {
            if (i == lenn - 1) {
                p3.myvec->push_front(p2.myvec->searchdata(i)+p1.myvec->searchdata(i));
            } else {
                int s = p2.myvec->searchdata(i) + p1.myvec->searchdata(i);
                int s2 = s % 10;
                s3 = s / 10;
                p3.myvec->push_front(s2);
                if (i + 1 < lenn)
                    p2.myvec->reassign(i + 1, s3 + p2.myvec->searchdata(i + 1));
            }
        }

    } else {

        for (int i = 0; i < lenn; i++) {
                int s = p2.myvec->searchdata(i) + p1.myvec->searchdata(i);
                int s2 = s % 10;
                s3 = s / 10;
                p3.myvec->push_front(s2);
                p2.myvec->reassign(i + 1, s3 + p2.myvec->searchdata(i + 1));
            }
    }
    if(p1.myvec->SIze()>p2.myvec->SIze()){
        for (int i = lenn; i < p1.myvec->SIze(); ++i) {
            if (i == p1.myvec->SIze() - 1) {
                p3.myvec->push_front(p1.myvec->searchdata(i));
            } else{
            if(p1.myvec->searchdata(i)>=10){
                int o=p1.myvec->searchdata(i)%10;
                int ss=(p1.myvec->searchdata(i))/10;
                p3.myvec->push_front(o);
                if(i+1<p1.myvec->SIze())
                   p1.myvec->reassign(i+1,ss+p1.myvec->searchdata(i+1));
            } else{
                p3.myvec->push_front(p1.myvec->searchdata(i));
            }
        }
    }
    } else{
        for (int i = lenn; i < p2.myvec->SIze(); ++i) {
            if (i == p2.myvec->SIze() - 1) {
                p3.myvec->push_front(p2.myvec->searchdata(i));
            } else{
                if(p2.myvec->searchdata(i)>=10){
                    int o=p2.myvec->searchdata(i)%10;
                    int ss=(p2.myvec->searchdata(i))/10;
                    p3.myvec->push_front(o);
                    if(i+1<p2.myvec->SIze())
                        p2.myvec->reassign(i+1,ss+p2.myvec->searchdata(i+1));
                } else{
                    p3.myvec->push_front(p2.myvec->searchdata(i));
                }
            }
        }
    }
    for (int i = 0; i < p3.myvec->SIze(); i++)
        str+=to_string(p3.myvec->searchdata(i));
        if(b==1){
            string st="-";
            for (int i = 0; i < str.size(); i++)
            {
                st+=str[i];
            }
            tt.myvec->deleteList();
            tt.myvec->push_back(-1*int(st[1]-'0'));
            for (int i = 2; i < st.size(); ++i)
                tt.myvec->push_back(int(st[i]-'0'));
            return tt;
        }
    tt.myvec->deleteList();
    for (int i = 0; i < str.size(); ++i) {
        tt.myvec->push_back(int(str[i]-'0'));
    }
        return tt;
}
op &op::operator += ( op& op2) {
    string tmp1;
    string final;
    string tmp2;
    string tmp2_;
    string tmp1_;
    op temp;
    op tt;
    temp.myvec->deleteList();
    int check_op1=1;
    int check_op2=1;
    int b=0;
    bool check_;
    int len=this->myvec->SIze();
    int len2=op2.myvec->SIze();
    for (int i = 0; i < len2; ++i)
        tmp2+= to_string(op2.myvec->searchdata(i));
    for (int i = 0; i <len ; ++i)
        tmp1+=to_string(this->myvec->searchdata(i));

    if(tmp1[0]=='-'){
        for (int i = 1; i < tmp1.size(); i++)
        {
            tmp1_+=tmp1[i];
            check_op1=0;
        }
    } else{
        for (int i = 0; i < tmp1.size(); i++)
            tmp1_+=tmp1[i];
    }
    if(tmp2[0]=='-'){
        for (int i = 1; i < tmp2.size(); i++)
        {
            tmp2_+=tmp2[i];
            check_op2=0;
        }
    } else{
        for (int i = 0; i < tmp2.size(); i++)
            tmp2_+=tmp2[i];
    }
    string str1=tmp1_;
    string str2=tmp2_;
    if(tmp1_==tmp2_){
        if(check_op1==0 || check_op2 ==0){
            if(check_op1==0 && check_op2==0){}
            else {
                temp.myvec->push_back(0);
                *this=temp;
                return *this;
            }
        }
    }
    if(check_op1==0||check_op2==0){
        if(check_op1==0&&check_op2==0)
            b=1;
        else
        {
            if(check_op1==0){
                check_=SAME(str1,str2);
                this->myvec->reassign(0,-1* this->myvec->searchdata(0));
                op gg=*this - op2;
                this->myvec->reassign(0,-1* this->myvec->searchdata(0));
                string t;
                if(gg.myvec->searchdata(0)<0){
                    for (int i = 0; i < gg.myvec->SIze(); ++i) {
                        if(i==0)
                            gg.myvec->reassign(0,-1*gg.myvec->searchdata(0));
                        t += to_string(gg.myvec->searchdata(i));
                    }
//                    reverse(t.begin(), t.end());
                    final=t;
                } else{
                    for (int i = 0; i < gg.myvec->SIze(); ++i) {
                        final+= to_string(int(gg.myvec->searchdata(i)));
                    }
                }
                if(check_== false){
                    string ff="-";
                    for (int i = 0; i < final.size(); ++i) {
                        ff+=final[i];
                    }
                    tt.myvec->deleteList();
                    tt.myvec->push_back(-1*int(ff[1]-'0'));
                    for (int i = 2; i < ff.size(); ++i)
                        tt.myvec->push_back(int(ff[i]-'0'));
                    *this=tt;
                    return *this;
                }else{
                    tt.myvec->deleteList();
                    for (int i = 0; i < final.size(); ++i) {
                        tt.myvec->push_back(int(final[i]-'0'));
                    }
                *this=tt;
                return *this;
                    }
                }
            else
            {
                op2.myvec->reassign(0,-1*op2.myvec->searchdata(0));
                op gg=*this-op2;
                op2.myvec->reassign(0,-1*op2.myvec->searchdata(0));
                string t;
                if(gg.myvec->searchdata(0)<0){
                    for (int i = 0; i < gg.myvec->SIze(); ++i) {
                        if(i==0)
                            gg.myvec->reassign(0,-1*gg.myvec->searchdata(0));
                            t += to_string(gg.myvec->searchdata(i));
                    }
                    //reverse(t.begin(), t.end());
                    final=t;
                }
                check_=SAME(str1,str2);
                if(check_==false){
                    *this=gg;
                    return *this;
                }
                else{
                    tt.myvec->deleteList();
                    tt.myvec->push_back(-1*int(final[0]-'0'));
                    for (int i = 1; i < final.size(); ++i)
                        tt.myvec->push_back(int(final[i]-'0'));
                    *this=tt;
                    return *this;
                }
            }
        }
    }
    op p1;
    op p2;
    op p3;
    p1.myvec->deleteList();
    p2.myvec->deleteList();
    p3.myvec->deleteList();
    for (int i = 0; i < str1.size(); i++)
        p1.myvec->push_front(int(str1[i]-'0'));
    for (int i = 0; i < str2.size(); i++)
    {
        p2.myvec->push_front(int(str2[i]-'0'));
    }
    int s3;
    int lenn;
    string str;
    if(p1.myvec->SIze()>p2.myvec->SIze())
        lenn=p2.myvec->SIze();
    else
        lenn=p1.myvec->SIze();
    if(p1.myvec->SIze()>p2.myvec->SIze()) {
        for (int i = 0; i < lenn; i++) {
            {
                int s = p1.myvec->searchdata(i) + p2.myvec->searchdata(i);
                int s2 = s % 10;
                s3 = s / 10;
                p3.myvec->push_front(s2);
                p1.myvec->reassign(i + 1, s3 + p1.myvec->searchdata(i + 1));
            }
        }
    } else if(this->myvec->SIze()==op2.myvec->SIze()){
        for (int i = 0; i < lenn; i++) {
            if (i == lenn - 1) {
                p3.myvec->push_front(p2.myvec->searchdata(i)+p1.myvec->searchdata(i));
            } else {
                int s = p2.myvec->searchdata(i) + p1.myvec->searchdata(i);
                int s2 = s % 10;
                s3 = s / 10;
                p3.myvec->push_front(s2);
                if (i + 1 < lenn)
                    p2.myvec->reassign(i + 1, s3 + p2.myvec->searchdata(i + 1));
            }
        }

    } else {

        for (int i = 0; i < lenn; i++) {
            int s = p2.myvec->searchdata(i) + p1.myvec->searchdata(i);
            int s2 = s % 10;
            s3 = s / 10;
            p3.myvec->push_front(s2);
            p2.myvec->reassign(i + 1, s3 + p2.myvec->searchdata(i + 1));
        }
    }
    if(p1.myvec->SIze()>p2.myvec->SIze()){
        for (int i = lenn; i < p1.myvec->SIze(); ++i) {
            if (i == p1.myvec->SIze() - 1) {
                p3.myvec->push_front(p1.myvec->searchdata(i));
            } else{
                if(p1.myvec->searchdata(i)>=10){
                    int o=p1.myvec->searchdata(i)%10;
                    int ss=(p1.myvec->searchdata(i))/10;
                    p3.myvec->push_front(o);
                    if(i+1<p1.myvec->SIze())
                        p1.myvec->reassign(i+1,ss+p1.myvec->searchdata(i+1));
                } else{
                    p3.myvec->push_front(p1.myvec->searchdata(i));
                }
            }
        }
    } else{
        for (int i = lenn; i < p2.myvec->SIze(); ++i) {
            if (i == p2.myvec->SIze() - 1) {
                p3.myvec->push_front(p2.myvec->searchdata(i));
            } else{
                if(p2.myvec->searchdata(i)>=10){
                    int o=p2.myvec->searchdata(i)%10;
                    int ss=(p2.myvec->searchdata(i))/10;
                    p3.myvec->push_front(o);
                    if(i+1<p2.myvec->SIze())
                        p2.myvec->reassign(i+1,ss+p2.myvec->searchdata(i+1));
                } else{
                    p3.myvec->push_front(p2.myvec->searchdata(i));
                }
            }
        }
    }
    for (int i = 0; i < p3.myvec->SIze(); i++)
        str+=to_string(p3.myvec->searchdata(i));
    if(b==1){
        string st="-";
        for (int i = 0; i < str.size(); i++)
        {
            st+=str[i];
        }
        temp.myvec->deleteList();
        temp.myvec->push_back(-1*int(st[1]-'0'));
        for (int i = 2; i < st.size(); i++) {
            temp.myvec->push_back(int(st[i]-'0'));
        }
        *this=temp;
        return *this;
    }
    temp.myvec->deleteList();
    for (int i = 0; i < str.size(); i++)
        temp.myvec->push_back(int(str[i]-'0'));
    *this=temp;
    return *this;
}
///////////////////////////////////////////////////////
op operator - (const op& op1,const op& op2)
{
    string tmp2_;
    string tmp1_;
	string tmp1;
    string tmp2;
    string temp;
    op op3;
    op3.myvec->deleteList();
    bool f_f_check= true;
    bool checker_op1=true;
    bool checker_op2=true;
    int len=op1.myvec->SIze();
    int len2=op2.myvec->SIze();
    for (int i = 0; i < len2; ++i)
        tmp2+= to_string(op2.myvec->searchdata(i));
    for (int i = 0; i <len ; ++i)
        tmp1+=to_string(op1.myvec->searchdata(i));
    if(tmp1[0]=='-'){
        for (int i = 1; i < tmp1.size(); i++)
        {
            tmp1_+=tmp1[i];
            checker_op1=false;
        }
    } else{
        for (int i = 0; i < tmp1.size(); i++)
            tmp1_+=tmp1[i];
    }
    if(tmp2[0]=='-'){
        for (int i = 1; i < tmp2.size(); i++)
        {
            tmp2_+=tmp2[i];
            checker_op2=false;
        }
    } else{
        for (int i = 0; i < tmp2.size(); i++)
            tmp2_+=tmp2[i];
    }
    if(tmp1_==tmp2_&& checker_op2==checker_op1){
        op3.myvec->push_back(0);
        return op3;
    }
    /****************************************************/
        if(checker_op1== true&&checker_op2== false){
            op2.myvec->reassign(0,-1*op2.myvec->searchdata(0));
            op f = op1 + op2;
            op2.myvec->reassign(0,-1*op2.myvec->searchdata(0));
            return f;
        }
        if(checker_op1== false&&checker_op2== true){
            op1.myvec->reassign(0,-1*op1.myvec->searchdata(0));
            op f= op1 + op2;
            string f2="-";
            for (int i = 0; i <f.myvec->SIze(); i++)
            {
                f2+= to_string(f.myvec->searchdata(i));
            }
            op1.myvec->reassign(0,-1*op1.myvec->searchdata(0));
            return f2;
        }
        string str1=tmp1_;
        string str2=tmp2_;
        if(checker_op1== false&&checker_op2== false){
                f_f_check= SAME(str1,str2);
        }
    if (SAME(str1,str2))
        swap(str1, str2);
	string str = "";
	int n1 = str1.length(), n2 = str2.length();
	reverse(str1.begin(), str1.end());
	reverse(str2.begin(), str2.end());

	int carry = 0;
	for (int i = 0; i < n2; i++) {
		int sub= ((str1[i] - '0') - (str2[i] - '0') - carry);
		if (sub < 0) {
			sub = sub + 10;
			carry = 1;
		}
		else
			carry = 0;

		str.push_back(sub + '0');
	}
	for (int i = n2; i < n1; i++) {
		int sub = ((str1[i] - '0') - carry);
		if (sub < 0) {
			sub = sub + 10;
			carry = 1;
		}
		else
			carry = 0;

		str.push_back(sub + '0');
    }
	reverse(str.begin(), str.end());
        int flag=0;
        for (int i = 0; i < str.size(); ++i) {
            if(str[i]=='0')
                flag++;
            else
                break;
        }
        string r1;
    for (int i = flag; i <str.size() ; ++i) {
        r1+=str[i];
    }
    temp=r1;
    if(f_f_check== false){
        string g="-";
        for (int i = 0; i <temp.size() ; ++i) {
            g += temp[i];
        }
        op3.myvec->deleteList();
        op3.myvec->push_back(-1*int(g[1]-'0'));
        for (int i = 2; i < g.size(); ++i) {
            op3.myvec->push_back(int (g[i]-'0'));
        }
        return op3;
    }
    if(checker_op1== true&&checker_op2== true){
        if(SAME(tmp1_,tmp2_)== true){
            string u="-";
            for (int i = 0; i < temp.size(); ++i) {
                u+=temp[i];
            }
            op3.myvec->deleteList();
            op3.myvec->push_back(-1*int(u[1]-'0'));
            for (int i = 2; i < u.size(); ++i) {
                op3.myvec->push_back(int (u[i]-'0'));
            }
            return op3;
        }
    }
    for (int i = 0; i < temp.size(); ++i) {
        op3.myvec->push_back(int(temp[i]-'0'));
    }
    return op3;
}

///////////////////////////////////////////////////////////
op op:: operator * (const op& op2){
    const op& op1=*this;
    op op3;
    op3.myvec->deleteList();
    int check_op1=0;
    int check_op2=0;
    string tmp1;
    string tmp2;
    string temp;
    int len=op1.myvec->SIze();
    int len2=op2.myvec->SIze();
    for (int i = 0; i < len2; ++i)
        tmp2+= to_string(op2.myvec->searchdata(i));
    for (int i = 0; i <len ; ++i)
        tmp1+=to_string(op1.myvec->searchdata(i));
        string tmp1_;
        string tmp2_;
    if(tmp1[0]=='-'){
        for (int i = 1; i < tmp1.size(); i++) {
            tmp1_+=tmp1[i];
        }
        check_op1=1;
    } else{
        tmp1_=tmp1;
    }
    if(tmp2[0]=='-'){
        for (int i = 1; i < tmp2.size(); i++) {
            tmp2_+=tmp2[i];
        }
        check_op2=1;
    } else{
        tmp2_=tmp2;
    }
    string m1=tmp1_;
    string m2=tmp2_;
    //**************************************************************//
    if (m1 == "0" || m2 == "0"){
        op3.myvec->push_back(0);
        return op3;
    }
    string multi(m1.size() + m2.size(), 0);
    for (int i = m1.size() - 1; i >= 0; i--) {
        for (int j = m2.size() - 1; j >= 0; j--) {
            int n = (m1[i] - '0') * (m2[j] - '0') + multi[i + j + 1];
            multi[i + j + 1] = n % 10;
            multi[i + j] += n / 10;
        }
    }
    for (int i = 0; i < multi.size(); i++)
        multi[i] += '0';
    if (multi[0] == '0')
         multi=multi.substr(1);
    if(check_op1==1||check_op2==1){
        if(check_op1==1&&check_op2==1){
            for (int i = 0; i < multi.size(); ++i) {
                op3.myvec->push_back(int(multi[i]-'0'));
            }
            return op3;
        }
        string tmp="-";
        for (int i = 0; i <multi.size() ; ++i) {
           tmp+=multi[i];
        }
        if(check_op1==1||check_op2==1){
            if(check_op1==1&&check_op2==1){
                for (int i = 0; i < multi.size(); ++i) {
                    op3.myvec->push_back(int(multi[i]-'0'));
                }
                return op3;
            }
            string tmp="-";
            for (int i = 0; i <multi.size() ; ++i) {
                tmp+=multi[i];
            }
            op3.myvec->push_back(-1*int(tmp[1]-'0'));
            for (int i = 2; i < tmp.size(); ++i)
                op3.myvec->push_back(int(tmp[i]-'0'));
            return op3;
        }
        return op3;
    }
    for (int i = 0; i < multi.size(); ++i) {
        op3.myvec->push_back(int(multi[i]-'0'));
    }
    return op3;
}
ostringstream op:: F(string a,string b)
{
    string s;
    ostringstream toof;
    int count,i;
    if("0"==b)
    {
        cout<<"bro amoo !"<<endl;
        exit(0);
    }
    {
        int index=0;
        while('0'==a[index])
            index++;
        a.erase(0,index);
        index=0;
        while('0'==b[index])
            index++;
        b.erase(0,index);
    }
    if(!Compare(a,b))
    {
        cout<<0<<" "<<a<<endl;
        exit(0);
    }
    int len=a.size();
    for(int i=0;i<len;i++)
    {
        count=0;
        s.push_back(a[i]);
        while(Compare(s,b))
        {
            s=fun(s,b);
            count++;
        }
            toof<<count;
    }
    return toof;
}
op op::operator / (const op& op2){

    op op1=*this;
    string tmp1;
    string tmp2;
    string temp;
    int check_op1=0;
    int check_op2=0;
    op op3;
    op3.myvec->deleteList();
    int len=op1.myvec->SIze();
    int len2=op2.myvec->SIze();
    for (int i = 0; i < len2; ++i)
        tmp2+= to_string(op2.myvec->searchdata(i));
    for (int i = 0; i <len ; ++i)
        tmp1+=to_string(op1.myvec->searchdata(i));
    string tmp1_;
    string tmp2_;
    if(tmp1[0]=='-'){
        for (int i = 1; i < tmp1.size(); i++) {
            tmp1_+=tmp1[i];
        }
        check_op1=1;
    } else{
        tmp1_=tmp1;
    }
    if(tmp2[0]=='-'){
        for (int i = 1; i < tmp2.size(); i++) {
            tmp2_+=tmp2[i];
        }
        check_op2=1;
    } else{
        tmp2_=tmp2;
    }
    string m1=tmp1_;
    string m2=tmp2_;
    bool a= SAME(m1,m2);
    if(a== true){
        this->myvec->deleteList();
        this->myvec->push_back(0);
        return *this;
    }
    ostringstream res= op::F(m1,m2);
    string s= res.str();
    for (int i = 0; s[0]==48 ; ++i) {
        s=s.substr((1));
    }
    if(check_op1==1||check_op2==1){
        if(check_op1==1&&check_op2==1){
            for (int i = 0; i < s.size(); ++i) {
                op3.myvec->push_back(int(s[i]-'0'));
            }
            return op3;
        }
    else
    {    
       string tmp="-";
       for (int i = 0; i <s.size() ; ++i) {
          tmp+=s[i];
       }
       op3.myvec->push_back(-1*int(tmp[1]-'0'));
        for (int i = 2; i < tmp.size(); ++i) {
            op3.myvec->push_back(int(tmp[i]-'0'));
        }
        return op3;
       }
    }
    for (int i = 0; i < s.size(); ++i) {
        op3.myvec->push_back(int(s[i]-'0'));
    }
    return op3;
}
op &op::operator /= (op& op2){
    string tmp1;
    op T;
    T.myvec->deleteList();
    string tmp2;
    string temp;
    int check_op1=0;
    int check_op2=0;
    int len=this->myvec->SIze();
    int len2=op2.myvec->SIze();
    for (int i = 0; i < len2; ++i)
        tmp2+= to_string(op2.myvec->searchdata(i));
    for (int i = 0; i <len ; ++i)
        tmp1+=to_string(this->myvec->searchdata(i));
        string tmp1_;
        string tmp2_;
    if(tmp1[0]=='-'){
        for (int i = 1; i < tmp1.size(); i++) {
            tmp1_+=tmp1[i];
        }
        check_op1=1;
    } else{
        tmp1_=tmp1;
    }
    if(tmp2[0]=='-'){
        for (int i = 1; i < tmp2.size(); i++) {
            tmp2_+=tmp2[i];
        }
        check_op2=1;
    } else{
        tmp2_=tmp2;
    }
    string m1=tmp1_;
    string m2=tmp2_;
    bool a= SAME(m1,m2);
    if(a== true){
        this->myvec->deleteList();
        this->myvec->push_back(0);
        return *this;
    }
    ostringstream res= op::F(m1,m2);
    string s= res.str();
    for (int i = 0; s[0]==48 ; ++i) {
        s=s.substr((1));
    }
    if(check_op1==1||check_op2==1){
        if(check_op2==1&&check_op1==1){
            for (int i = 0; i < s.size(); ++i)
                T.myvec->push_back(s[i]-'0'); 
                *this=T;
            return *this;
        }
        string tmp="-";
        for (int i = 0; i <s.size() ; i++) {
          tmp+=s[i];
        }
        if(check_op1==1){
            T.myvec->push_back(-1 * int(tmp[1] - '0'));
            for (int i = 2; i < tmp.size(); i++) 
                    T.myvec->push_back(int(tmp[i])-'0');
            *this=T;
        }else{
            T.myvec->push_back(-1 * int(tmp[1] - '0'));
            for (int i = 2; i < tmp.size(); i++) 
                    T.myvec->push_back(int(tmp[i])-'0');
            *this=T;
        }
            return *this;
        }
        for (int i = 0; i < s.size(); i++)
            T.myvec->push_back(s[i]-'0');
            *this=T;
        return *this;
}
string op::fun(string num1,string num2)
{
    bool fushu = false;
    if(num1.size()<num2.size())
    {
        string temp = num1;
        num1 = num2;
        num2 = temp;
        fushu = true;
    }
    else if(num1.size() == num2.size())
    {
        int len = num1.size();
        for(int i=0;i<len;++i)
        {
            if(num1[i] == num2[i])
                continue;
            if(num1[i]>num2[i])
                break;
            if(num1[i]<num2[i])
            {
                string temp = num1;
                num1 = num2;
                num2 = temp;
                fushu = true;
            }
        }
    }
    int len1 = num1.size();
    int len2 = num2.size();
    int* toof = new int[len1];
    int index = 0;
    for(int i=len1-1;i >=0;--i)
        toof[index++]=num1[i]-'0';
    index = 0;
    for(int i=len2-1;i>=0;--i)
    {
        int num = num2[i]-'0';
        if(num>toof[index])
        {
            toof[index+1] -=1;
            toof[index] = 10+toof[index] - num;
        }
        else
            toof[index] = toof[index] - num;
        ++index;
    }
    index = len1-1;
    while(toof[index] == 0)
        --index;
    ostringstream osstr;
    if(fushu == true)
        osstr<<'-';
    for(int i=index;i>=0;--i)
        osstr<<toof[i];
    delete toof;
    return osstr.str();
}
op &op::operator *= ( op& op2){
    int check_op1=0;
    int check_op2=0;
    string tmp1;
    string tmp2;
    string temp;
    op T;
    T.myvec->deleteList();
    int len=this->myvec->SIze();
    int len2=op2.myvec->SIze();
    for (int i = 0; i < len2; ++i)
        tmp2+= to_string(op2.myvec->searchdata(i));
    for (int i = 0; i <len ; ++i)
        tmp1+=to_string(this->myvec->searchdata(i));
        string tmp1_;
        string tmp2_;
    if(tmp1[0]=='-'){
        for (int i = 1; i < tmp1.size(); i++) {
            tmp1_+=tmp1[i];
        }
        check_op1=1;
    } else{
        tmp1_=tmp1;
    }
    if(tmp2[0]=='-'){
        for (int i = 1; i < tmp2.size(); i++) {
            tmp2_+=tmp2[i];
        }
        check_op2=1;
    } else{
        tmp2_=tmp2;
    }
    string m1=tmp1_;
    string m2=tmp2_;
    //**************************************************************//
    if (m1 == "0" || m2 == "0") {
        T.myvec->push_back(0);
        *this=T;
        return *this;
    }
    string multi(m1.size() + m2.size(), 0);
    for (int i = m1.size() - 1; i >= 0; i--) {
        for (int j = m2.size() - 1; j >= 0; j--) {
            int n = (m1[i] - '0') * (m2[j] - '0') + multi[i + j + 1];
            multi[i + j + 1] = n % 10;
            multi[i + j] += n / 10;
        }
    }
    for (int i = 0; i < multi.size(); i++) {
      multi[i] += '0';
    }
    if (multi[0] == '0')
      multi=multi.substr(1);
    if(check_op1==1||check_op2==1){
        if(check_op1==1&&check_op2==1){
            for (int i = 0; i < multi.size(); ++i)
                T.myvec->push_back(multi[i]-'0');
            *this=T;
            return *this;
        }
        string tmp="-";
        for (int i = 0; i <multi.size() ; ++i)
            tmp+=multi[i];
        T.myvec->push_back(-1*int(multi[0]-'0'));
        for (int i = 1; i <multi.size(); i++)
            T.myvec->push_back(multi[i]-'0');
        *this=T;
        return *this;
    }
    for (int i = 0; i <multi.size(); ++i)
        T.myvec->push_back(multi[i]-'0');
        *this=T;
    return *this;
   
}
op &op::operator -= ( op& op2)
{
    op T;
    T.myvec->deleteList();
    string tmp2_;
    string tmp1_;
    string tmp1;
    string tmp2;
    string temp;
    bool f_f_check= true;
    bool checker_op1=true;
    bool checker_op2=true;
    int len= this->myvec->SIze();
    int len2=op2.myvec->SIze();
    for (int i = 0; i < len2; ++i)
        tmp2+= to_string(op2.myvec->searchdata(i));
    for (int i = 0; i <len ; ++i)
        tmp1+=to_string(this->myvec->searchdata(i));
    if(tmp1[0]=='-'){
        for (int i = 1; i < tmp1.size(); i++)
        {
            tmp1_+=tmp1[i];
            checker_op1=false;
        }
    } else{
        for (int i = 0; i < tmp1.size(); i++)
            tmp1_+=tmp1[i];
    }
    if(tmp2[0]=='-'){
        for (int i = 1; i < tmp2.size(); i++)
        {
            tmp2_+=tmp2[i];
            checker_op2=false;
        }
    } else{
        for (int i = 0; i < tmp2.size(); i++)
            tmp2_+=tmp2[i];
    }
    if(tmp1_==tmp2_&& checker_op1==checker_op2) {
        T.myvec->push_back(0);
        *this=T;
        return *this;
    }
    /****************************************************/
    if(checker_op1== true&&checker_op2== false){
        op2.myvec->reassign(0,-1*op2.myvec->searchdata(0));
        op ff= *this + op2;
        string f;
        for (int i = 0; i < ff.myvec->SIze(); ++i) {
            f+= to_string(ff.myvec->searchdata(i));
        }
        op2.myvec->reassign(0,-1*op2.myvec->searchdata(0));
        for (int i = 0; i < f.size(); ++i)
            T.myvec->push_back(int(f[i]-'0'));
        *this=T;
        return *this;
    }
    if(checker_op1== false&&checker_op2== true){
        this->myvec->reassign(0,-1*this->myvec->searchdata(0));
        op ff= *this + op2;
        string f;
        for (int i = 0; i < ff.myvec->SIze(); ++i) {
            f+= to_string(ff.myvec->searchdata(i));
        }
        string f2="-";
        for (int i = 0; i <f.size() ; i++)
        {
            f2+=f[i];
        }
        T.myvec->push_back(-1*int(f2[1]-'0'));
        for (int i = 2; i < f2.size(); ++i) {
            T.myvec->push_back(int(f2[i]-'0'));
        }
        *this=T;
        return *this;
    }
    string str1=tmp1_;
    string str2=tmp2_;
    if(checker_op1== false&&checker_op2== false){
        f_f_check= SAME(str1,str2);
    }
    if (SAME(str1,str2))
        swap(str1, str2);
    string str = "";
    int n1 = str1.length(), n2 = str2.length();
    reverse(str1.begin(), str1.end());
    reverse(str2.begin(), str2.end());

    int carry = 0;
    for (int i = 0; i < n2; i++) {
        int sub= ((str1[i] - '0') - (str2[i] - '0') - carry);
        if (sub < 0) {
            sub = sub + 10;
            carry = 1;
        }
        else
            carry = 0;

        str.push_back(sub + '0');
    }
    for (int i = n2; i < n1; i++) {
        int sub = ((str1[i] - '0') - carry);
        if (sub < 0) {
            sub = sub + 10;
            carry = 1;
        }
        else
            carry = 0;

        str.push_back(sub + '0');
    }
    reverse(str.begin(), str.end());
    int flag=0;
    for (int i = 0; i < str.size(); ++i) {
        if(str[i]=='0')
            flag++;
        else
            break;
    }
    string r1;
    for (int i = flag; i <str.size() ; ++i) {
        r1+=str[i];
    }
    temp=r1;
    if(f_f_check== false){
        string g="-";
        for (int i = 0; i <temp.size() ; ++i) {
            g += temp[i];
        }
        T.myvec->push_back(-1*int(g[1]-'0'));
        for (int i = 2; i < g.size(); ++i) {
            T.myvec->push_back(int(g[i]-'0'));
        }
        *this=T;
        return *this;
    }
    if(checker_op1== true&&checker_op2== true){
        if(SAME(tmp1_,tmp2_)== true){
            string u="-";
            for (int i = 0; i < temp.size(); ++i) {
                u+=temp[i];
            }
            T.myvec->push_back(-1*int(u[1]-'0'));
            for (int i = 2; i < u.size(); ++i) {
            T.myvec->push_back(int(u[i]-'0'));
            }
            *this=T;
            return *this;
        }
    }
    for (int i = 0; i < temp.size(); ++i)
        T.myvec->push_back(int(temp[i]-'0'));
    *this=T;
    return *this;

}
