class point
{
    int x, y;

public:
    
    point(int x1, int y1);
    point(int t);
    int getX();
    int getY();
    void setX(int x1);
    void setY(int y1);
    void set(int x1, int y1);
    float length();
    void print();
};