#include <iostream>
#include "point.h"
using namespace std;
int main(){
    point pnt1{0}, pnt2{20, 30};
    pnt1.print();
    pnt2.print();
    cout << pnt2.length();
}