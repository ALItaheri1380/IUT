#include <iostream>
#include <cmath>
#include "point.h"
using namespace std;
point::point(int t)
{
    if (t == 0)
    {
        x = 0;
        y = 0;
    }
}

point::point(int x1, int y1)
{
    x = x1;
    y = y1;
}

int point::getX()
{
    return x;
}

int point::getY()
{
    return y;
}

void point::setX(int x1)
{
    x = x1;
}

void point::setY(int y1)
{
    y = y1;
}

void point::set(int x1, int y1)
{
    x = x1;
    y = y1;
}

float point::length()
{
    return sqrt(x*x + y*y);
}

void point::print(){
    cout <<"("<<x<<","<< y <<")"<< endl;
}