#include<iostream>
#include <sstream>
#include <string>
#include"vactor.h"
using namespace std;
class Cache
{
protected:
    int cp{0}; // capacity
    vactor<int>* keyvec=new vactor<int>;
    vactor<int>* myvec=new vactor<int>;
    virtual void set(int, int) = 0; // set function
    virtual void get(int) = 0; // get function
};
class abstract:Cache{

public:
    abstract(int cp_) {
        cp = cp_;
    }
    void get(int key){
        int index=-1;
        index=keyvec->search(key);  
        if(index==-1){
            cout<<-1<<'\n';
            return;
        }
        int tmp=myvec->searchdata(index);
        cout<<tmp<<endl;
        myvec->Delete(index);
        keyvec->Delete(index);
        myvec->push_front(tmp);
        keyvec->push_front(key);
    }
    void set(int key,int data) {

        int check = keyvec->search(key);
        if (check == -1) {
            keyvec->push_front(key);
            myvec->push_front(data);
            if (cp < myvec->SIze()) {
                myvec->pop_back();
                keyvec->pop_back();
            }
        } else{
            myvec->Delete(check);
            keyvec->Delete(check);
            keyvec->push_front(key);
            myvec->push_front(data);
        }
    }
//    void print(){
//        cout<<"\nkeyvec is\n";
//        keyvec->PrintLinkedList();
//        cout<<"\nmyvec is\n";
//        myvec->PrintLinkedList();
//    }
};
int main(){
    int flag=0;
    int m,n;
    cin>>m>>n;
    abstract simpale(n);
    for (int i = 0; i < m; ++i) {
        string line;
        string wich;
        if(flag==0) {
            getline(cin, line);
            getline(cin, line);
        } else{
            getline(cin, line);
        }
        flag++;
        istringstream is( line );
        is>>wich;
        if(wich=="set"){
            int index;
            int data;
            is>>index;
            is>>data;
            simpale.set(index,data);
        }
        else{
            int index;
            is>>index;
            simpale.get(index);
        }
    }

}