#include<iostream>
#include"Node.h"
#include<string>
using namespace std;
template<typename T>class vactor{
    private:
        Node<T>* head;
    public:
     void PrintLinkedList()
        {
            Node<T>* mynode = new Node<T>;
            mynode=head;
            while (mynode!= NULL)
            {
              cout<<mynode->get_data()<<"->";
              mynode=mynode->get_next();

             }
         cout<<"NULL"<<endl;
         return;
         }

        vactor(){
            this->head = NULL;
        }
     int SIze(){
        Node<T>* mynode = new Node<T>;
        mynode=head;
        int f=0;
        while (mynode != NULL)
            {
               mynode=mynode->get_next();
                f++;
            }
            return f;
        }
     double Avg(string a,string b){
            Node<T>* mynode = new Node<T>;
            mynode=head;
            double sum=0;
            double avg;
            int flag=0;
            while (mynode!=NULL)
            {
                sum+=(mynode->get_data()).size();
                mynode=mynode->get_next();
                flag++;
            }
            if(flag==0){
                return 0;
            }
            avg=sum/flag;
            return avg;
            
        }
     double Avg(int x){
            Node<T>* mynode = new Node<T>;
            mynode=head;
            double sum=0;
            double avg;
            int flag=0;
            while (mynode!=NULL)
            {
                sum+=(mynode->get_data());
                mynode=mynode->get_next();
                flag++;
            }
            if (flag==0){
                return 0;
            }
            avg=sum/flag;
            return avg;
        }
     void push_front(T data)
        {
            Node<T> node;
            Node<T>* newNode = node.CreateNode(data);
            newNode->set_next(head);
            head = newNode;  
        }
     void push_back(T data)
        {
            Node<T> node;
            Node<T> *o = node.CreateNode(data);
            if(head==nullptr){
                push_front(data);
                return;
            }
            Node<T>*temp=head->get_next();
            if (temp== nullptr)
            {
                head->set_next(o);
            }
            else
            {
                while (temp->get_next()!=NULL)
                {
                    temp=temp->get_next();
                }
                temp->set_next(o);
            }
        }
     void pop_front()
         {

             if (head!=NULL)
            {
                 Node<T>* tmp = (head)->get_next();
                 free(head);
                 head = tmp;
            }
         }
     void pop_back()
        {
            if (head!=NULL)
            {
            Node<T>* tmp = head;
            Node<T>* old = head;
            for(;tmp->get_next()!=NULL;tmp = tmp->get_next()){
            old=tmp;
            }
            old->set_next( NULL);
            free(tmp);
            }
        }
     void bubble_sort_LinkedList(int x)
        {
        int n = SIze()-1;
        
        while(n--)

        {
            Node<T>* prev =NULL;
            Node<T>*cur = head;
            while(cur->get_next()!=NULL)
            {
                if(cur->get_data() >=cur->get_next()->get_data())
                {
                    
                    if(prev==NULL)
                    {
                        //first node
                        Node<T>* nxt = cur->get_next();
                        cur->set_next(nxt->get_next());
                        nxt->set_next(cur);
                        prev=nxt ;
                        head = prev ;
                    
                        
                    }
                    
                    else
                    {
                        
                        Node<T>* nxt = cur->get_next() ;
                        prev->set_next(nxt);
                        cur->set_next(nxt->get_next()) ;
                        nxt->set_next(cur) ;
                        prev = nxt ;   
                    }   
                }
                else
                {
                    prev = cur ; 
                    cur=cur->get_next();  
                }
            }   
        }  
        // if(cur->data.size() >=cur->next->data.size())
}
 void bubble_sort_LinkedList(string p,string p2)
        {
                int n = SIze()-1;
        
        while(n--)

        {
            Node<T>* prev =NULL;
            Node<T>*cur = head;
            while(cur->get_next()!=NULL)
            {
                if(cur->get_data().size() >=cur->get_next()->get_data().size())
                {
                    
                    if(prev==NULL)
                    {
                        //first node
                        Node<T>* nxt = cur->get_next();
                        cur->set_next(nxt->get_next());
                        nxt->set_next(cur);
                        prev=nxt ;
                        head = prev ;
                    
                        
                    }
                    
                    else
                    {
                        
                        Node<T>* nxt = cur->get_next() ;
                        prev->set_next(nxt);
                        cur->set_next(nxt->get_next()) ;
                        nxt->set_next(cur) ;
                        prev = nxt ;   
                    }   
                }
                else
                {
                    prev = cur ; 
                    cur=cur->get_next();  
                }
            }   
        }  
}
         void insert(int index, T data){
            Node<T> node;
            if (index == 0)
                push_front(data);
            else{
                int dd;
                Node<T>* tmp = head;
                Node<T>* old = head;
                for(dd=0;dd<index;dd++)
                {
                    if (tmp == NULL)
                        break;
                    old = tmp;
                    tmp = tmp->get_next();
                }
                if (tmp == NULL && index == dd)
                    push_back(data);
                else 
                {
                    if(index == dd && tmp != NULL){
                        Node<T>* newNode = node.CreateNode(data);
                        newNode->set_next(tmp);
                        old->set_next(newNode);
                    }
                    else
                    cout<<"invalid input size!";    
                    
                }
            }
        }
         void Delete(int index)
        {
            if (index < 0)
                cout<<"invalid input size!"<<endl;
            else
            {
                if (index == 0)
                   pop_front();
                else
                {
                    int dd ;
                    Node<T>* tmp = head;
                    Node<T>* old = head;
                    for(dd=0;dd!=index;dd++){
                        if (tmp->get_next() == NULL)
                            break;
                        old = tmp;
                        tmp = tmp->get_next();
                    }
                    if (tmp == NULL && index == dd)
                        pop_front();
                    else if (index == dd && tmp != NULL)
                    {
                        old->set_next(tmp->get_next());
                        free(tmp);
                    }
                    else
                        cout<<"invalid input size!"<<endl;
                }
            }
        }
        int search(T key){
	    Node<T>* tmp = new Node<T>;
        int indx = -1;
        tmp = head;
        if(tmp== nullptr)
            return -1;
        if(tmp->get_data()==key)
           return 0;
        while (true) {
            if (tmp->get_next() != NULL) {
                if (tmp->get_data() == key) {
                    return indx+1;
                }
                else {
                    tmp = tmp->get_next();
                    indx++;
                }
            }
            else
                if (tmp->get_data() == key)
                    return indx+1;
                else
                    break;

        }
        return -1;
}
            string maxx(string z1,string z2){
            Node<T>* mynode = new Node<T>;
            mynode=head;
            // int x=mynode->data.size();
            int x=mynode->get_data().size();
            string Max=mynode->get_data();
            while (mynode!=NULL)
            {
                if(mynode->get_data().size() > x){
                    Max=mynode->get_data();       
                    x=Max.size(); 
                }      
                mynode=mynode->get_next(); 
            }
            return Max;
        }
        
        double maxx(int zz)
        {
            Node<T>* mynode = new Node<T>;
            mynode=head;
            double M=mynode->get_data();    
            while (mynode != NULL){
                if (mynode->get_data() > M)
                    M = mynode->get_data();
                mynode=mynode->get_next();    
            }
            return M;
        } 
        Node<T>* searchNode( int index)///tabe azafe vase car khodame
        {
            Node<T>* tmp = head;
            int ff ;
            for(ff=0;ff !=  index;ff++){
                tmp = tmp->get_next();
            }
            return tmp;
        }
        void swap( int index1, int index2)
        {
            Node<T>* node1 = searchNode( index1);
            Node<T>* node2 = searchNode( index2);
            T tmp = node1->get_data();
            node1->set_data(node2->get_data());
            node2->set_data(tmp);
        }
        void deleteList()
        {
            Node<T>* current = head;
            Node<T>* next = NULL;
            while (current != NULL)
            {
                next = current->get_next();
                free(current);
                current = next;
            }
            head = NULL;
        }
        void reassign(int index,T newdata){
            Node<T> node;
            Delete(index);
            insert(index,newdata);
        }
        T searchdata(int index){
            Node<T>* tmp=head;
            for (int i = 0; i < index; i++)
                tmp=tmp->get_next();
            return tmp->get_data();
        }
};
