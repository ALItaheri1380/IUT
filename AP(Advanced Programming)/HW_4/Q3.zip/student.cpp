#include<iostream>
#include<string>
#include"student.h"
using namespace std;
int student::g(0);
double student::sum(0);
int num = 100;
student:: student(double grade_=0,string name_="empty",string famil_="empty"){
    number="400"+to_string(num)+"3";
    num++;
    g++;
    sum+=grade_;
    grade=grade_;
    famil=famil_;
    name=name_;
    if(grade_>0){
        check=false;
        adad=grade_;
    }
}
void student:: set_grade(double grade_){
    if(check==false){
        sum-=adad;
    }
    grade=grade_;
    sum+=grade_;
}
void student:: set_name(string name_){
    name=name_;
}
void student:: set_famil(string famil_){
    famil=famil_;
}
void student:: set_number(string number_){
    number=number_;
}
double student::  get_grade() const{
    return grade;
}
string student:: get_name() const{
    return name;
}
string student:: get_number() const{
    return number;
}
string student:: get_famli() const{
    return famil;
}
int student::  tedad()  {
    return g;
}
double student:: avg(){
    return sum/g;
}
student:: ~student(){
    cout<<"end of class\n";
}