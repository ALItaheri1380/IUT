#include"student.h"
#include<iostream>
using namespace std;
int main() {
    student arr{12, "ali", "taheri"};
    cout << arr.get_number() << endl;
    cout << arr.get_famli() << '\n';
    cout << arr.get_name() << endl;
    cout << arr.get_grade() << endl;
    student arr2{15, "mmd", "mohamadi"};
    cout << arr2.get_number() << endl;
    cout << arr2.get_famli() << '\n';
    cout << arr2.get_name() << endl;
    cout << arr2.get_grade() << endl;
    student arr3{18.4, "zahra", "hadian"};
    cout << arr3.get_number() << endl;
    cout << arr3.get_famli() << '\n';
    cout << arr3.get_name() << endl;
    cout << arr3.get_grade() << endl;
    cout << student::avg() << endl;
    cout << student::tedad() << endl;
    return 0;
}