using namespace std;
#include<string>
class student{
private:
    double grade{0};
    string name ;
    string famil;
    string number;
    bool check=true;//age ba costractoor ye meghdar dadi bad az set estefade cardi bayad oon meghdaro kam koni
    double adad=0;
    static int g;//tedad
    static double sum;
public:
    student(double grade_,string name_,string famil_);
    void set_grade(double grade_);
    void set_name(string name_);
    void set_famil(string famil_);
    void set_number(string number_);
    double get_grade() const;
    string get_name() const;
    string get_number() const;
    string get_famli() const;
    static int  tedad();
    static double avg();
    ~student();
};

     