#include<iostream>
#include"vactor.h"
using namespace std;
int main(){
   //--------------------------------------//
   /*string a="ali";
    string alaki="kswuf";
    string alaki2="ftdyi";
    string b="lalalalal";
    string c="jasjjsjj";
    string z="a";
    string q="lklklk";
    string zz="zzzzz";
    vactor<string> x;
    x.push_front(c);
    x.push_front(b);
    x.push_front(zz);
  	x.push_front(z);
    x.push_front(a);
    x.PrintLinkedList();
    cout<<"-----\n";
    cout<<x.search(a)<<endl; 
    cout<<x.Avg(alaki,alaki2)<<'\n';
    cout<<x.maxx(alaki,alaki2)<<endl;
    cout<<"---------\n";
    x.reassign(0,q);
    x.PrintLinkedList();
    cout<<"---------\n";
    x.swap(0,1);
    x.PrintLinkedList();
    cout<<"---------\n";
    x.insert(0,"alallalalaaaaaaaaaaaaaaaaa");
    x.bubble_sort_LinkedList(alaki2,alaki);
    x.PrintLinkedList();*/
    //----------------------------------------//
    //------------------------------------   
    /*double a=12.1;
     double b=10;
     double c=2;
     double d=101;
     double alalki=1000000;
     vactor<double> x;
     x.push_back(b);
     x.push_back(c);
     x.push_back(a);
    // x.bubble_sort_LinkedList(alalki);
     x.PrintLinkedList();
    x.reassign(0,199);
     cout<<"-----\n";
     x.PrintLinkedList();
     cout<<x.Avg(alalki);*/
     //-------------------------------------//
     char a='a';
     char b='b';
     char c='d';
     char d='h';
     char r='d';
     int alalki=1000000;
     vactor<char> x;
     x.push_front(a);
     x.push_front(b);
     x.push_back(c);
     x.push_back(d);
     x.PrintLinkedList();
     cout<<"\n//---------------------------------------------\n";
     cout<<x.maxx(alalki)<<'\n';
     cout<<x.Avg(alalki);
     cout<<"\n//----+-+-+-+-++-+-+-+------\n";
     x.bubble_sort_LinkedList(46);
     x.PrintLinkedList();
     cout<<"\n//+++++++++++++++++++++++++++++++++++++++++++\n";
     x.swap(0,1);
     x.reassign(0,r);
     x.PrintLinkedList();
     cout<<"\n//---------\n";
     cout<<x.SIze()<<endl;
     //-------------------------------------------//
}