#pragma once
#include<iostream>
using namespace std;
template<typename T>class Node {
private:
    T data;
    Node<T>* next;
public:
    Node() {
        this->next = nullptr;
    }
    void set_next(Node<T>* tmp) {
        next = tmp;
    }
    Node<T>* get_next() {
        return next;
    }
    void set_data(T data_) {
        data = data_;
    }
    T get_data() {
        return data;
    }
    Node<T>* CreateNode(T data) {
        Node<T>* mynode = new Node<T>;
        mynode->set_data(data);
        mynode->set_next(nullptr);
        return mynode;
    }
    void printNode(Node<T> node) {
        cout << node.get_data() << endl;
    }
};