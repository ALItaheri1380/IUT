#pragma once
#include"store.h"
#include <string>
//******************************************************************//
void store::print(Node<mobail>* N) {
    cout << "model is -->" << N->get_data().get_model() << "\nbrand is-->" <<
        N->get_data().get_brand() << "\ncolore is-->" << N->get_data().get_colore() << "\nprice is-->" <<
        N->get_data().get_price() << "\nresolation is-->" << N->get_data().get_resolation() << '\n' << "\n//-----------------\n" << endl;
}
//*****************************************************************//
void store::filter_price(int q) {
    Node<mobail>* M;
    M = x->get_head();
    while (M != NULL)
    {
        if (M->get_data().get_price() < q)
            print(M);
        M = M->get_next();
    }
}
//*****************************************************************//
void  store::filter_resolation(int q) {
    Node<mobail>* M;
    M = x->get_head();
    while (M != NULL)
    {
        if (M->get_data().get_resolation() == q)
            print(M);
        M = M->get_next();
    }
}
//*****************************************************************//
void  store::filter_brand(vactor<string>q) {
    Node<string>* M;
    Node<mobail>* N;
    N = x->get_head();
    while (N != NULL)
    {
        M = q.get_head();
        while (M != NULL)
        {
            if (N->get_data().get_brand() == M->get_data())
                print(N);
            M = M->get_next();
        }
        N = N->get_next();
    }
}
//*************************************************************//
void  store::filter_model(vactor<string> q) {
    Node<string>* M;
    Node<mobail>* N;
    N = x->get_head();
    while (N != NULL)
    {
        M = q.get_head();
        while (M != NULL)
        {
            if (N->get_data().get_model() == M->get_data())
                print(N);
            M = M->get_next();
        }
        N = N->get_next();
    }
}
//************************************************************//
void  store::filter_price(vactor<string> q) {
    Node<string>* M;
    Node<mobail>* N;
    N = x->get_head();
    while (N != NULL)
    {
        M = q.get_head();
        while (M != NULL)
        {
            if (to_string(N->get_data().get_price()) == M->get_data())
                print(N);
            M = M->get_next();
        }
        N = N->get_next();
    }
}
//***************************************************************//
void  store::filter_resolation(vactor<string> q) {
    Node<string>* M;
    Node<mobail>* N;
    N = x->get_head();
    while (N != NULL)
    {
        M = q.get_head();
        while (M != NULL)
        {
            if (to_string(N->get_data().get_resolation()) == M->get_data())
                print(N);
            M = M->get_next();
        }
        N = N->get_next();
    }
}
//**********************************************************************//
void  store::filter_colore(vactor<string> q) {
    Node<string>* M;
    Node<mobail>* N;
    N = x->get_head();
    while (N != NULL)
    {
        M = q.get_head();
        while (M != NULL)
        {
            if (N->get_data().get_colore() == M->get_data())
                print(N);
            M = M->get_next();
        }
        N = N->get_next();
    }
}
//********************************PUBLIC**********************************//
    void  store::add_class_to_vactor(mobail& newmobail) {
        x->push_back(newmobail);
    }
    void  store::search(string type, vactor<string> q) {
        if (type == "brand")
            filter_brand(q);
        if (type == "model")
            filter_model(q);
        if (type == "price")
            filter_price(q);
        if (type == "resolation")
            filter_resolation(q);
        if (type == "colore")
            filter_colore(q);
    }
    void  store::search(string type, int q) {
        Node<mobail>* M;
        M = x->get_head();
        if (type == "price")
            filter_price(q);
        else
            filter_resolation(q);
    }