#pragma once
#include"mobail.h"
void mobail::set_model(string model_) {
    model = model_;
}
void mobail::set_brand(string brand_) {
    brand = brand_;
}
void mobail::set_colore(string colore_) {
    colore = colore_;
}
void mobail::set_resolation(double resolation_) {
    resolation = resolation_;
}
void mobail::set_price(double price_) {
    price = price_;
}
string mobail::get_model() const {
    return model;
}
string mobail::get_colore() const {
    return colore;
}
string mobail::get_brand() const {
    return brand;
}
double mobail::get_price() const {
    return price;
}
double mobail::get_resolation() const {
    return resolation;
}