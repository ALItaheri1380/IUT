#pragma once
#include<iostream>
#include"store.h"
#include<string>
using namespace std;
int main() {
    string q = "Galaxy win";
    string q2 = "Galaxy Note 10";
    string q3 = "a 10 s";
    string l = "sumsung";
    string l2 = "apple";
    string l3 = "a70";
    double p = 1000;
    double p2 = 1021;
    double p3 = 900;
    string g = "black";
    string g2 = "red";
    string g3 = "blue";
    double b = 50;
    double b2 = 54;
    double b3 = 38;
    mobail a;
    a.set_brand(q3);
    a.set_colore(g);
    a.set_model(l3);
    a.set_price(p);
    a.set_resolation(b);

    mobail o;
    o.set_brand(q);
    o.set_colore(g2);
    o.set_model(l);
    o.set_price(p2);
    o.set_resolation(b3);
    mobail i;
    i.set_brand(q2);
    i.set_colore(g3);
    i.set_model(l2);
    i.set_price(p3);
    i.set_resolation(b2);
    store zz;
    zz.add_class_to_vactor(a);
    zz.add_class_to_vactor(o);
    zz.add_class_to_vactor(i);
    vactor<string> ss;
    ss.push_back(q);
    ss.push_front(q2);
    vactor<string> xx;
    xx.push_front(to_string(p));
    xx.push_front(to_string(p2));
    zz.search("brand", ss);
    cout << "//-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-\n";
    cout << "//-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-\n";
    cout << "//-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-\n";
    zz.search("price", 1010);
    cout << "//-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-\n";
    cout << "//-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-\n";
    cout << "//-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-\n";
    zz.search("price", xx);
    cout << "//-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-\n";
    cout << "//-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-\n";
    cout << "//-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-\n";
    zz.search("resolation", 38);
}