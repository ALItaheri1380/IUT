#pragma once
#include<iostream>
using namespace std;
class mobail {
private:
    string model;
    string brand;
    double price;
    double resolation;
    string colore;
public:
    void set_model(string model_);
    void set_brand(string brand_);
    void set_colore(string colore_);
    void set_resolation(double resolation_);
    void set_price(double price_);
    string get_model() const;
    string get_colore() const;
    string get_brand() const;
    double get_price() const;
    double get_resolation() const;
};