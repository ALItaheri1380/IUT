#pragma once
#include"vactor.h"
#include"mobail.h"
#include"Node.h"
#include<iostream>
using namespace std;
class store {
private:
    vactor<mobail>* x = new vactor<mobail>;
    void print(Node<mobail>* N);
    void filter_price(int q);
    void filter_resolation(int q);
    void filter_brand(vactor<string>q);
    void filter_model(vactor<string> q);
    void filter_price(vactor<string> q);
    void filter_resolation(vactor<string> q);
    void filter_colore(vactor<string> q);
public:
    void add_class_to_vactor(mobail& newmobail);
    void search(string type, vactor<string> q);
    void search(string type, int q);
};
