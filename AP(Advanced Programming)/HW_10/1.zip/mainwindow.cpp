#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include <QFile>
#include <QTextStream>
#include <QCoreApplication>
#include <QString>
#include <QDebug>
#include <QTextStream>
#include <QJsonDocument>
#include <QJsonObject>
#include "mygialog.h"
#include "dialog2.h"
#include "dialog3.h"
#include "dialog4.h"
#include <QMessageBox>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::on_pushButton_clicked()
{
   mygialog *d = new mygialog(this);
   d->show();
   connect(d,SIGNAL(add_item(QString,QString)),this,SLOT(add_item(QString,QString)));
}
void MainWindow::add_item(QString n,QString m){
    int ret;
    QMessageBox msgBox;
    msgBox.setText("Click the save button to append this item");
    ret = msgBox.exec();
    ui->lineEdit->setText(n);
    ui->plainTextEdit->setPlainText(m);
}

void MainWindow::on_pushButton_4_clicked()
{
    Dialog4 *d = new Dialog4(this);
    d->show();
    connect(d,SIGNAL(add_item_4(QString)),this,SLOT(add_item_4(QString)));
}
void MainWindow::add_item_4(QString find){
   int i=0;
   for(i;i<Namevect.size();i++)
   {
           if(find==Namevect[i])
               break;
   }
   ui->plainTextEdit->setPlainText(addressvect[i]);
   ui->lineEdit->setText(find);
}
void MainWindow::on_pushButton_2_clicked()
{
    Dialog2 *d = new Dialog2(this);
    d->show();
    connect(d,SIGNAL(add_item_2(QString,QString)),this,SLOT(add_item_2(QString,QString)));
}
void MainWindow::add_item_2(QString n,QString m){
        for(int i=0 ; i<Namevect.size();i++)
        {
           if(Namevect[i]==n){
               addressvect.replace(i,m);
           }
        }
        ui->lineEdit->clear();
        ui->plainTextEdit->clear();
}

void MainWindow::on_pushButton_3_clicked()
{
    Dialog3 *d = new Dialog3(this);
    d->show();
    connect(d,SIGNAL(add_item_3(QString)),this,SLOT(add_item_3(QString)));
}
void MainWindow::add_item_3(QString n){
    for(int i=0 ; i<Namevect.size();i++)
    {
        if(Namevect[i]==n)
        {
          addressvect.remove(i);
          Namevect.remove(i);
        }
    }
    ui->lineEdit->clear();
    ui->plainTextEdit->clear();
}
void MainWindow::on_pushButton_9_clicked()
{
    QString next = ui->lineEdit->text();
    int i=0;
    for(i ; i < Namevect.size() ; i++ ){
        if(next==Namevect[i])
            break;
    }
    ui->lineEdit->clear();
    ui->plainTextEdit->clear();
    if(i>=Namevect.size()-1)
    {
        ui->plainTextEdit->setPlainText(addressvect[i]);
        ui->lineEdit->setText(Namevect[i]);
    }
    else
    {
        ui->plainTextEdit->setPlainText(addressvect[i+1]);
        ui->lineEdit->setText(Namevect[i+1]);
    }
}
void MainWindow::on_pushButton_8_clicked()
{
    QString next = ui->lineEdit->text();
    int i=0;
    for(i ; i < Namevect.size() ; i++ ){
        if(next==Namevect[i])
            break;
    }
    ui->lineEdit->clear();
    ui->plainTextEdit->clear();
    if(i<=0)
    {
        ui->plainTextEdit->setPlainText(addressvect[i]);
        ui->lineEdit->setText(Namevect[i]);
    }
    else{
        ui->plainTextEdit->setPlainText(addressvect[i-1]);
        ui->lineEdit->setText(Namevect[i-1]);
    }
}
void MainWindow::on_pushButton_6_clicked(){
    Namevect.push_back(ui->lineEdit->text());
    addressvect.push_back(ui->plainTextEdit->toPlainText());
    ui->plainTextEdit->clear();
    ui->lineEdit->clear();
}
void MainWindow::on_actionexit_triggered()
{
    exit(0);
}

