#include "mygialog.h"
#include "ui_mygialog.h"

mygialog::mygialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::mygialog)
{
    ui->setupUi(this);
}

mygialog::~mygialog()
{
    delete ui;
}

void mygialog::on_buttonBox_accepted()
{
    emit add_item(ui->lineEdit->text(),ui->plainTextEdit->toPlainText());
}

