#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_9_clicked();

    void on_pushButton_8_clicked();

    void on_pushButton_6_clicked();

    void on_actionexit_triggered();

    void add_item(QString,QString);

    void add_item_2(QString,QString);

    void add_item_3(QString);

    void add_item_4(QString);

    void on_pushButton_7_clicked();

    void add_item_5(QString x);

    void on_pushButton_5_clicked();

    void Add_item(int);
private:
    QString File_name = "empty";
private:
    Ui::MainWindow *ui;
private:
    int Item=0;
private:
    QVector<QString> Namevect;
    QVector<QString> addressvect;
};
#endif // MAINWINDOW_H
