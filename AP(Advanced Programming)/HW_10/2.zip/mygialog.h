#ifndef MYGIALOG_H
#define MYGIALOG_H

#include <QDialog>

namespace Ui {
class mygialog;
}

class mygialog : public QDialog
{
    Q_OBJECT

public:
    explicit mygialog(QWidget *parent = nullptr);
    ~mygialog();

private slots:
    void on_buttonBox_accepted();
signals:
   void add_item(QString,QString);
private:
    Ui::mygialog *ui;
};

#endif // MYGIALOG_H
