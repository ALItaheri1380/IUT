#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include <QFile>
#include <QTextStream>
#include <QString>
#include <QMessageBox>
#include <QTextStream>
#include <QJsonDocument>
#include <QJsonObject>
#include "mygialog.h"
#include "dialog2.h"
#include "dialog3.h"
#include "dialog4.h"
#include "dialog5.h"
#include "dialog6.h"
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::on_pushButton_clicked()
{
    if(Item != 1 && Item != 2){
        int ret;
        QMessageBox msgBox;
        msgBox.setText("First select the Export button for type  the file");
        ret = msgBox.exec();
        return;
   }
   mygialog *d = new mygialog(this);
   d->show();
   connect(d,SIGNAL(add_item(QString,QString)),this,SLOT(add_item(QString,QString)));
}
void MainWindow::add_item(QString n,QString m){
    int ret;
    QMessageBox msgBox;
    msgBox.setText("Click the save button to append this item");
    ret = msgBox.exec();
    ui->lineEdit->setText(n);
    ui->plainTextEdit->setPlainText(m);
}
void MainWindow::on_pushButton_4_clicked()
{
    Dialog4 *d = new Dialog4(this);
    d->show();
    connect(d,SIGNAL(add_item_4(QString)),this,SLOT(add_item_4(QString)));
}
void MainWindow::add_item_4(QString find){
   int i=0;
   bool Chek = false;
   for(i;i<Namevect.size();i++)
   {
           if(find==Namevect[i]){
               Chek = true;
               break;
           }
   }
   if(Chek == false){
       int ret;
       QMessageBox msgBox;
       msgBox.setText("this address was not exist.");
       ret = msgBox.exec();
       return;
   }
   ui->plainTextEdit->setPlainText(addressvect[i]);
   ui->lineEdit->setText(find);
}
void MainWindow::on_pushButton_2_clicked()
{
    if(Item != 1 && Item != 2){
        int ret;
        QMessageBox msgBox;
        msgBox.setText("First select the Export button for type the file");
        ret = msgBox.exec();
        return;
    }
    Dialog2 *d = new Dialog2(this);
    d->show();
    connect(d,SIGNAL(add_item_2(QString,QString)),this,SLOT(add_item_2(QString,QString)));
}
void MainWindow::add_item_2(QString n,QString m){
        for(int i=0 ; i<Namevect.size();i++)
        {
           if(Namevect[i]==n){
               addressvect.replace(i,m);
           }
        }
        ui->lineEdit->clear();
        ui->plainTextEdit->clear();
        on_pushButton_6_clicked();
}

void MainWindow::on_pushButton_3_clicked()
{
    if(Item != 1 && Item != 2){
        int ret;
        QMessageBox msgBox;
        msgBox.setText("First select the Export button for type  the file");
        ret = msgBox.exec();
        return;
    }
    Dialog3 *d = new Dialog3(this);
    d->show();
    connect(d,SIGNAL(add_item_3(QString)),this,SLOT(add_item_3(QString)));
}
void MainWindow::add_item_3(QString n){
    for(int i=0 ; i<Namevect.size();i++)
    {
        if(Namevect[i]==n)
        {
          addressvect.remove(i);
          Namevect.remove(i);
        }
    }
    ui->lineEdit->clear();
    ui->plainTextEdit->clear();
    on_pushButton_6_clicked();
}
void MainWindow::on_pushButton_9_clicked()
{
    QString next = ui->lineEdit->text();
    int i=0;
    for(i ; i < Namevect.size() ; i++ ){
        if(next==Namevect[i])
            break;
    }
    ui->lineEdit->clear();
    ui->plainTextEdit->clear();
    if(i>=Namevect.size()-1)
    {
        ui->plainTextEdit->setPlainText(addressvect[i]);
        ui->lineEdit->setText(Namevect[i]);
    }
    else
    {
        ui->plainTextEdit->setPlainText(addressvect[i+1]);
        ui->lineEdit->setText(Namevect[i+1]);
    }
}
void MainWindow::on_pushButton_8_clicked()
{
    QString next = ui->lineEdit->text();
    int i=0;
    for(i ; i < Namevect.size() ; i++ ){
        if(next==Namevect[i])
            break;
    }
    ui->lineEdit->clear();
    ui->plainTextEdit->clear();
    if(i<=0)
    {
        ui->plainTextEdit->setPlainText(addressvect[i]);
        ui->lineEdit->setText(Namevect[i]);
    }
    else{
        ui->plainTextEdit->setPlainText(addressvect[i-1]);
        ui->lineEdit->setText(Namevect[i-1]);
    }
}
void MainWindow::on_pushButton_6_clicked(){
    if(ui->lineEdit->text()!= ""){
        Namevect.push_back(ui->lineEdit->text());
        addressvect.push_back(ui->plainTextEdit->toPlainText());
        ui->plainTextEdit->clear();
        ui->lineEdit->clear();
    }
    if(Item==1){
        QJsonObject obj;
        for(int i = 0 ; i < Namevect.size() ; i++)
             obj[Namevect[i]]=addressvect[i];
        QJsonDocument d(obj);
        QFile myfile("ALIJ.json");
        myfile.open(QIODevice::WriteOnly);
        myfile.write(d.toJson());
        myfile.close();
    }
    else if(Item==2){
        QFile file("ALIN.txt");
        if(!file.open(QFile::WriteOnly | QFile::Text))
        {
             qDebug() << " Could not open file for writing";
             return;
        }
        QTextStream out(&file);
        int i=0;
        while (i < Namevect.size())
        {
             out << Namevect[i]<<','<<addressvect[i]<<'\n';
             i++;
        }
        file.flush();
        file.close();
    }
    else{
          int ret;
          QMessageBox msgBox;
          msgBox.setText("First select the Export button for type the file");
          ret = msgBox.exec();
    }
}
void MainWindow::on_pushButton_5_clicked()
{
      Dialog6 *d = new Dialog6(this);
      d->show();
      connect(d,SIGNAL(add_item_6(QString)),this,SLOT(add_item_5(QString)));
}
void MainWindow::add_item_5(QString name){
    File_name = name ;
    QFile myfile(name);
    if(myfile.exists()) {
        int i = 0;
        QChar Type;
        while(i<File_name.size()){
            if(File_name[i]=='.'){
                Type = File_name[i+1];
                break;
            }
          i++;
        }
        if(Type == 'j' || Type == 'J'){
            myfile.open(QIODevice::ReadOnly);
            QByteArray mylist =  myfile.readAll();
            QJsonDocument D = QJsonDocument::fromJson(mylist);
            QJsonObject obj = D.object();
            QStringList myList = obj.keys();
            for(int i =0 ; i < myList.size() ; i++ ){
                  Namevect.push_back(myList[i]);
                  QString Val = obj[myList[i]].toString();
                   addressvect.push_back(Val);
             }
        }
        else{
             if(!myfile.open(QFile::ReadOnly |QFile::Text))
             {
                 qDebug() << " Could not open the file for reading";
                 return;
             }
             QTextStream in(&myfile);
             while (!in.atEnd()){
                 QString myText = in.readLine();
                 int g=0;
                 QStringList List = myText.split(',');
                 int flag=0;
                 foreach(QString item, List){
                     if(flag==0)
                           Namevect.push_back(item);
                     else
                           addressvect.push_back(item);
                  flag++;
                 }
             }
             myfile.close();
        }
    }
    else{
        int ret;
        QMessageBox msgBox;
        msgBox.setText("file dose not exists.");
        ret = msgBox.exec();
    }
}
void MainWindow::on_actionexit_triggered()
{
    exit(0);
}
void MainWindow::on_pushButton_7_clicked()
{
    Dialog5 *d = new Dialog5(this);
    d->show();
    connect(d,SIGNAL(add_item_5(int)),this,SLOT(Add_item(int)));

}
void MainWindow::Add_item(int x){
    Item = x;
}
