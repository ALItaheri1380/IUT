#include "dialog5.h"
#include "ui_dialog5.h"

Dialog5::Dialog5(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog5)
{
    ui->setupUi(this);
}

Dialog5::~Dialog5()
{
    delete ui;
}

void Dialog5::on_buttonBox_accepted()
{
    int choose;
    if(ui->radioButton->isChecked())
        choose = 1;
    else if(ui->radioButton_2->isChecked())
         choose = 2;
    emit add_item_5(choose);
}

