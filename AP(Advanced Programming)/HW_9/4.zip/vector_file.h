#pragma once
#include<iostream>
#include<string>
#include "Node.h"
#include <sstream>
#include <fstream>
using namespace std;
template<typename T>class vector_file{
public:
   static string Type()
    {
            T t;
            int t2;
            float t3;
            double t4;
            char t5;
            string t6;
            const type_info &ti1 = typeid(t);
            const type_info &ti2 = typeid(t2);
            const type_info &ti3 = typeid(t3);
            const type_info &ti4 = typeid(t4);
            const type_info &ti5 = typeid(t5);
            const type_info &ti6 = typeid(t6);
            if (ti1 == ti2)
                return "int\n";
            if (ti1 == ti3)
                return "float\n";
            if (ti1 == ti4)
                return "double\n";
            if (ti1 == ti5)
                return "char\n";
            if (ti1 == ti6)
                return "string\n";
    }
    static void decrypt (string NAME_)
    {
        char ch;
        fstream fps, fpt;
        fps.open(NAME_, fstream::in);
        fpt.open("tmp.txt", fstream::out);
        while(fps>>noskipws>>ch) {
            ch = ch - (1000*1000+200);
            fpt << ch;
        }
        fps.close();
        fpt.close();
        std::remove(NAME_.c_str());
        std::rename("tmp.txt", NAME_.c_str());
        cout<<endl;
    }
    static void Encrypt(string NAME_)
    {
        char ch;
        fstream fploy, fpt;
        fploy.open(NAME_, fstream::in);
        fpt.open("tmp.txt", fstream::out);
        while(fploy>>noskipws>>ch)
        {
            ch = ch+(1000*1000+200);
            fpt<<ch;
        }
        fploy.close();
        fpt.close();
        fploy.open(NAME_, fstream::out);
        fpt.open("tmp.txt", fstream::in);
        while(fpt>>noskipws>>ch)
            fploy<<ch;
        fploy.close();
        fpt.close();
        std::remove(NAME_.c_str());
        std::rename("tmp.txt", NAME_.c_str());
    }
    static void add(Node<T>* emp,string name_)
    {
        ofstream file(name_,ios::binary);
        Node<T>* temp=emp;
        file<<Type();   
        while (temp!=NULL)
        {
           file<<temp->get_data()<< endl;
           temp=temp->get_next();
        }
        file.close();
        Encrypt(name_);
    }
    static Node<int>* F_file(Node<int>* Head,string name_)
    {
        ifstream MYread_fil(name_,ios::binary);
        string text;
        int flag=0;
        string sw_t;
        while(getline(MYread_fil, text)){
            if(flag==0)
            {
                sw_t=Type();
                if(text[0]!=sw_t[0])
                {
                    cout<<"invalid type vector";
                    Encrypt(name_);
                    exit(0);
                }    
            }
            else
            {
                Node<int> node;
                Node<int> *o = node.CreateNode(stoi(text));
                if(Head==nullptr){
                    Node<int> *newNode =new Node<int>;
                    newNode->set_next(nullptr);
                    int s= stoi(text);
                    newNode->set_data(s);
                    newNode->set_next(Head);
                    Head = newNode;
                } else {
                    Node<int> *temp = Head->get_next();
                    if (temp == nullptr) {
                        Head->set_next(o);
                    } else {
                        while (temp->get_next() != NULL) {
                            temp = temp->get_next();
                        }
                        temp->set_next(o);
                    }
                }
            }
            flag++;
        }
        return Head;
    }
    static Node<double>* F_file(Node<double>* Head,string name_)
    {
        ifstream MYread_fil(name_,ios::binary);
        string text;
        int flag=0;
        string sw_t;
        while(getline(MYread_fil, text)){
              if(flag==0)
                {
                    sw_t=Type();
                    if(text[0]!=sw_t[0])
                    {
                        cout<<"invalid type vector";
                        Encrypt(name_);
                        exit(0);
                    }    
                }
                else
                {
                    vector_file<double>* newvect=new vector_file<double>;
                    Node<double> node;
                    Node<double> *o = node.CreateNode(stod(text));
                    if(Head==nullptr){
                        Node<double> *newNode =new Node<double>;
                        newNode->set_next(nullptr);
                        double s= stod(text);
                        newNode->set_data(s);
                        newNode->set_next(Head);
                        Head = newNode;
                    } else {
                        Node<double> *temp = Head->get_next();
                        if (temp == nullptr) {
                            Head->set_next(o);
                        } else {
                            while (temp->get_next() != NULL) {
                                temp = temp->get_next();
                            }
                            temp->set_next(o);
                        }
                    }
                }
               flag++;
            }
            return Head;
    }
    static Node<float>* F_file(Node<float>* Head,string name_)
    {
        int flag=0;
        string sw_t;
        ifstream MYread_fil(name_,ios::binary);
        string text;
        while(getline(MYread_fil, text)){
        if(flag==0)
            {
                sw_t=Type();
                if(text[0]!=sw_t[0])
                {
                    cout<<"invalid type vector";
                    Encrypt(name_);
                    exit(0);
                }    
            }
            else
            {
                Node<float> node;
                Node<float> *o = node.CreateNode(stof(text));
                if(Head==nullptr){
                    Node<float> *newNode =new Node<float>;
                    newNode->set_next(nullptr);
                    float s= stof(text);
                    newNode->set_data(s);
                    newNode->set_next(Head);
                    Head = newNode;
                } else {
                    Node<float> *temp = Head->get_next();
                    if (temp == nullptr) {
                        Head->set_next(o);
                    } else {
                        while (temp->get_next() != NULL) {
                            temp = temp->get_next();
                        }
                        temp->set_next(o);
                    }
                  }
               }
               flag++;
            }    
        return Head;
    }
    static Node<string>* F_file(Node<string>* Head,string name_)
    {
            int flag=0;
            ifstream MYread_fil(name_,ios::binary);
            string text;
            while(getline(MYread_fil, text)){
            string sw_t;
            if(flag==0)
            {
                sw_t=Type();
                if(text[0]!=sw_t[0])
                {
                    cout<<"invalid type vector";
                    Encrypt(name_);
                    exit(0);
                }    
            }
            else
            {
                    Node<string> node;
                    Node<string> *o = node.CreateNode(text);
                    if(Head==nullptr){
                        Node<string> *newNode =new Node<string>;
                        newNode->set_next(nullptr);
                        newNode->set_data(text);
                        newNode->set_next(Head);
                        Head = newNode;
                    } else {
                        Node<string> *temp = Head->get_next();
                        if (temp == nullptr) {
                            Head->set_next(o);
                        } else {
                            while (temp->get_next() != NULL) {
                                temp = temp->get_next();
                            }
                            temp->set_next(o);
                        }
                    }
                }
            flag++;
            }
        return Head;
    }
    static Node<char>* F_file(Node<char>* Head,string name_)
    {
            ifstream MYread_fil(name_,ios::binary);
            string text;
            int flag=0;
            while(getline(MYread_fil, text)){
            string sw_t;
            if(flag==0)
            {
                sw_t=Type();
                if(text[0]!=sw_t[0])
                {
                    cout<<"invalid type vector";
                    Encrypt(name_);
                    exit(0);
                }    
            }
            else
            {

                    vector_file<char>* newvect=new vector_file<char>;
                    Node<char> node;
                    char w=text[0];
                    Node<char> *o = node.CreateNode(w);
                    if(Head==nullptr){
                        Node<char> *newNode =new Node<char>;
                        newNode->set_next(nullptr);
                        newNode->set_data(w);
                        newNode->set_next(Head);
                        Head = newNode;
                    } else {
                        Node<char> *temp = Head->get_next();
                        if (temp == nullptr) {
                            Head->set_next(o);
                        } else {
                            while (temp->get_next() != NULL) {
                                temp = temp->get_next();
                            }
                            temp->set_next(o);
                        }
                    }
                }
            flag++;
            }
        return Head;
    }
    static Node<T>* load_data(string name_)
    {
            decrypt(name_);
            Node<T> *Head = new Node<T>;
            Head = NULL;
            string tp;
            Head = F_file(Head,name_);
            Encrypt(name_);
            return Head;
    }
     static bool exists_file (string& name) {
        ifstream f(name.c_str());
        return f.good();
    }


};