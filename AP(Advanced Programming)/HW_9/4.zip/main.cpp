#pragma once
#include<iostream>
#include"vactor.h"
using namespace std;
void string_vect(int sw)
{
    string a = "ali";
    string alaki = "kswuf";
    string alaki2 = "ftdyi";
    string b = "lalalalal";
    string c = "jasjjsjj";
    string z = "a";
    string q = "lklklk";
    string zz = "zzzzz";
    vactor<string> x(sw);
    x.push_front(c);
    x.push_front(b);
    x.push_front(zz);
    x.push_front(z);
    x.push_front(a);
    x.PrintLinkedList();
    cout<<"are you like to save this data in file? enter yes\n";
    string t;
    cin>>t;
    if(t=="yes")
    {
        string Name_;
        cout<<"enter name of file = ";
        cin>>Name_;
        x.savedata(Name_);
    }
}
void double_vect(int sw)
{
    double a = 12.2;
    double b = 10.22;
    double c = 2.1233;
    vactor<double> x(sw);
    x.push_front(b);
    x.push_front(c);
    x.push_front(a);
    x.PrintLinkedList();
    cout<<"are you like to save this data in file? enter yes\n";
    string t;
    cin>>t;
    if(t=="yes")
    {
        string Name_;
        cout<<"enter name of file = ";
        cin>>Name_;
        x.savedata(Name_);
    }
}
void int_vect(int sw)
{
    int a = 12;
    int b = 10;
    int c = 23;
    vactor<int> x(sw);
    x.push_front(b);
    x.push_front(c);
    x.push_front(a);
    x.PrintLinkedList();
    cout<<"are you like to save this data in file? enter yes\n";
    string t;
    cin>>t;
    if(t=="yes")
    {
        string Name_;
        cout<<"enter name of file = ";
        cin>>Name_;
        x.savedata(Name_);
    }
}
void float_vect(int sw)
{
    float a = 12.2;
    float b = 10.22;
    float c = 2.1233;
    vactor<float> x(sw);
    x.push_front(b);
    x.push_front(c);
    x.push_front(a);
    x.PrintLinkedList();
    cout<<"are you like to save this data in file? enter yes\n";
    string t;
    cin>>t;
    if(t=="yes")
    {
        string Name_;
        cout<<"enter name of file = ";
        cin>>Name_;
        x.savedata(Name_);
    }
}
void char_vect(int sw){
    char a = 'a';
    char b = 'b';
    char c = 'd';
    char d = 'h';
    char r = 'd';
    vactor<char> x(sw);
    x.push_front(a);
    x.push_front(b);
    x.push_front(c);
    x.push_front(d);
    x.PrintLinkedList();
    cout<<"are you like to save this data in file? enter yes\n";
    string t;
    cin>>t;
    if(t=="yes")
    {
        string Name_;
        cout<<"enter name of file = ";
        cin>>Name_;
        x.savedata(Name_);
    }
}
int main(){
   //--------------------------------------//
       cout<<"chose your vector.\n";
       cout<<"1- int\n";
       cout<<"2- float\n";
       cout<<"3- double\n";
       cout<<"4- char\n";
       cout<<"5- string\n";
       int s;
       cin>>s;
       if(s==1)
       {
          int_vect(s);
       }
       if(s==2){
           float_vect(s);
       }
       if(s==3){
           double_vect(s);
       }
       if(s==4){
           char_vect(s);
       }
       if(s==5){
           string_vect(s);
       }

}