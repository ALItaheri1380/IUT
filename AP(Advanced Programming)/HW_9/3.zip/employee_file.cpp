#include "employee_file.h"
using namespace std;
employee_file::employee_file(int employeeId, std::string name, int birthYear, int salary) : employee(employeeId, name, birthYear, salary) {
    fstream file("employees.txt",ios::out | ios::app);
    file.close();
}
string employee_file::employee_to_str(employee emp)
{
    return to_string(emp.getId()) + "," +emp.getName() + "," +to_string(emp.getbirthday()) + "," +to_string(emp.getSalary());
}
employee employee_file::str_to_emoloyee(string line)
{
   employee emp(0, "");
    string delim = ",";
    size_t pos = 0;
    string token1;
    int flag=0;
    while (( pos = line.find (delim)) != std::string::npos)
    {
        token1 = line.substr(0, pos); // store the substring
        if(flag==0)
            emp.setEmployeeId(stoi(token1));
        else if(flag==1)
            emp.setName(token1);
        else if(flag==2)
            emp.setbirthday(stoi(token1));
        line.erase(0, pos + delim.length());
        flag++;
    }
    emp.setSalary(stoi(line));
    return emp;

}
void employee_file::push_file(const employee &emp)
{
    ofstream file("employees.txt", ios::app);
    file << employee_to_str(emp) << endl;
    file.close();
}

bool employee_file::exist(int employeeId)
{
    ifstream file("employees.txt");
    string line;
    while (file >> line)
    {
        string value = line.substr(0, line.find(','));
        if (stoi(value) == employeeId)
        {
            file.close();
            return true;
        }
    }
    file.close();
    return false;
}
void employee_file::modify(int employeeId, const employee &updatedEmp)
{
    ifstream file("employees.txt");
    ofstream tempFile("temp.txt");
    string line;
    int flag=0;
    while (file >> line)
    {
        string value = line.substr(0, line.find(','));
        if (stoi(value) == employeeId)
        {
            line = employee_to_str(updatedEmp);
            flag++;
        }
        tempFile << line << endl;
    }
    if(flag==0)
        cout<<"\nEmployee does not exist\n\n";
    file.close();
    tempFile.close();
    string file_Name="employees.txt";
    std::remove(file_Name.c_str());
    rename("temp.txt", file_Name.c_str());
}
void employee_file::Remove(int employeeId)
{
    ifstream file("employees.txt");
    ofstream tempFile("temp.txt");
    string line;
    while (file >> line)
    {
        string value = line.substr(0, line.find(','));
        if (stoi(value) != employeeId)
            tempFile << line << endl;
    }
    file.close();
    tempFile.close();
    string file_Name="employees.txt";
    std::remove(file_Name.c_str());
    rename("temp.txt", file_Name.c_str());
}

employee employee_file::find(int employeeId)
{
    ifstream file("employees.txt");
    string line;
    while (file >> line)
    {
        string value = line.substr(0, line.find(','));
        if (stoi(value) == employeeId)
        {
            file.close();
            return str_to_emoloyee(line);
        }
    }
}
string& employee_file::replace(string& str, string from, string to)
{
    size_t pos;
    while ((pos = str.find(from)) != string::npos)
        str.replace(pos, 1, to);
    return str;
}
void employee_file::saveAs(string fileName_)
{
    ifstream file("employees.txt");
    ofstream newFile(fileName_);
    string line;
    while (file >> line)
    {
        line = replace(line, ",", "                    ");
        newFile << line << endl;
    }
    file.close();
    newFile.close();
}
