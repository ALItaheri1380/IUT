#pragma once
#include <string>
using namespace std;
class employee
{
private:
    int id;
    string name;
    int birth_year;
    int salary;
public:
    employee(int employeeId, string name,int birthYear = 1990, int salary = 1000);
    int getId();
    string getName();
    int getbirthday();
    int getSalary();
    void setEmployeeId(int);
    void setName(string);
    void setbirthday(int);
    void setSalary(int);
};