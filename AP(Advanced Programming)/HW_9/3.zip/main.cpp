#include "employee_file.h"
#include <string>
employee_file sample(0, std::string(), 0, 0);
using namespace std;
void addRecord()
{
    int empId,birthYear,salary;
    string name;
    cout<<"\n pls enter ID  and  birthday and  salary and name. tnx :)"<<'\n';
    cin>>empId>>birthYear>>salary>>name;
    employee emp(empId, name, birthYear, salary);
    sample.push_file(emp);
}
void listRecord()
{
    ifstream file("employees.txt");
    string line;
    while (file >> line)
    {
        string delim = ",";
        size_t pos = 0;
        string token1;
        int flag=0;
        while (( pos = line.find (delim)) != std::string::npos)
        {
            token1 = line.substr(0, pos); // store the substring
            if(flag==0)
                cout <<"   ID is = " <<  token1;
            else if(flag==1)
                cout << "   name is = "<< token1;
            else if(flag==2)
                cout << "   birthday is = "<<token1;

            line.erase(0, pos + delim.length());  /* erase() function store the current positon and move to next token. */
            flag++;
        }
        cout << "   salary is = " <<line<<endl;
    }
    file.close();
}

void modifyRecord()
{
    int empId,birthYear,salary;
    string name;
    cout<<"\n pls enter ID  and  birthday and  salary and name. tnx :)"<<'\n';
    cin>>empId>>birthYear>>salary>>name;
    employee emp(empId, name, birthYear, salary);
    sample.modify(empId, emp);
}
void deleteRecord()
{
    int empId;
    cout<<"enter id = ";
    cin>>empId;
    if (employee_file::exist(empId))
    {
        employee_file::Remove(empId);
    }
    else
        cout << "Employee does not exist!\n";
}

void searchRecord()
{
    int empId;
    cout<<"enter id = ";
    cin>>empId;
    if (employee_file::exist(empId))
    {
        employee emp = employee_file::find(empId);
        cout << "      ID =  " << emp.getId()<< "     Name of employees = " << emp.getName()<< "    Birth day is =  " << emp.getbirthday()
        << "      Salary =  " << emp.getSalary() << endl;
    }
    else
        cout << "Employee does not exist!\n";
}
void saveRecord()
{
    string fileName;
    cout<<"enter file name = ";
    cin>>fileName;
    employee_file::saveAs(fileName);
}
int main()
{
    int choice;
    cout << "1-Add Record\n"<<"2-ListRecord\n"<<"3-ModifyRecord\n"<<"4-DeleteRecord\n"<<"5-SearchRecord\n"<<"6-SaveRecord\n"<<"7-Exit\n";
    while (true)
    {
        cout<<"enter choise =   ";
        cin>>choice;
        if(choice==1)
                addRecord();
        else if(choice==2)
                listRecord();
        else if(choice==3)
                modifyRecord();
        else if(choice==4)
                deleteRecord();
        else if(choice==5)
                searchRecord();
        else if(choice==6)
                saveRecord();
        else if(choice==7)
                exit(0);

    }
}