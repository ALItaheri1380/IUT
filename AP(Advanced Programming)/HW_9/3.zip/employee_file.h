#pragma once
#include <iostream>
#include <fstream>
#include "employee.h"
class employee_file:public employee
{
public:
    static string& replace(string&,string,string);
    static string employee_to_str(employee);
    static employee str_to_emoloyee(string);
    employee_file(int, string, int, int);
    void push_file(const employee&);
    static bool exist(int);
    void modify(int, const employee&);
    static void Remove(int);
    static employee find(int);
    static void saveAs(string);
};