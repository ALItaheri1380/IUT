#include "employee.h"
#include <stdexcept>
int employee::getId(){
    return id;
}
string employee::getName(){
    return name;
}
int employee::getbirthday(){
    return birth_year;
}
int employee::getSalary(){
    return salary;
}

employee::employee(int employeeId, std::string name_,int birthYear_, int salary_)
{
    id = employeeId;
    name = name_;
    birth_year = birthYear_;
    salary = salary_;
}
void employee::setEmployeeId(int id_)
{
    id = id_;
}

void employee::setName(std::string name_)
{
    name = name_;
}

void employee::setbirthday(int year)
{
    birth_year = year;
}

void employee::setSalary(int salary_)
{
    salary = salary_;
}