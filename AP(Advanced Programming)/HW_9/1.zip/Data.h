#pragma once
#include <stdexcept>
using namespace std;
class Date
{
private:
	int year;
	int month;
	int day;
public:
	Date(int year=2000, int month=12, int day=10);
	int getYear();
	int getMonth();
	int getDay();
};
class thr_except : public exception
{
	virtual const char *what() const throw();
};