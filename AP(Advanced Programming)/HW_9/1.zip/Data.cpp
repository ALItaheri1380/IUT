#include "Data.h"
int Date::getYear(){
    return year;
}
int Date::getMonth(){
    return month;
}
int Date::getDay(){
    return day;
}
Date::Date(int year_, int month_, int day_)
{
    if (year_ <= 1 || year_ >=3000)
        throw thr_except();
    if (month_ <= 0 || month_ > 12)
        throw out_of_range("out_of_range\n");
    if (day_<= 0 || day_ > 31)
        throw day;
    year = year_;
    month = month_;
    day = day_;
}

const char *thr_except::what() const throw()
{
    return "invalid year\n";
}