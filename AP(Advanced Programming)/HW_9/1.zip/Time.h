#pragma once
#include <exception>
using namespace std;
class Time
{
private:
	int hour;
	int minute;

public:
	Time(int hour=12, int minute=0);
	int getHour() const;
	int getMinute();
};
class TimeException : exception
{
public:
	enum h_m_error
	{
		H,
		M
	};
	int day = 0;
    virtual const char *what() const throw();
    TimeException(h_m_error error, int day = 0);
    h_m_error error() const;
    int getDay() const;
private:
	char exp[50];
    h_m_error error_name;
};