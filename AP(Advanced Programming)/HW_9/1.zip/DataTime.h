#pragma once
#include <ostream>
#include "Data.h"
#include "time.h"
class DateTime
{
private:
    Date* date;
    Time* time;
public:
    DateTime(int year_=0, int month_=0, int day_=0, int hour_=0, int minute_=0);
    int getYear();
    int getMonth();
    int getDay();
    int getHour();
    int getMinute();
    friend ostream& operator<<(ostream& out, const DateTime& obj);
};
class exception_varieble : public exception
{
    const char *exp;
    virtual const char *what() const throw();
public:
    exception_varieble(const char *error);
};