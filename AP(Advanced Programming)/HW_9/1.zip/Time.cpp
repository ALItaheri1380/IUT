#include "time.h"
#include <cstring>

Time::Time(int hour_, int minute_)
{
    if (hour_ <= 0 || hour_ > 24)
        throw TimeException(TimeException::h_m_error::H);
    if (minute_ < 0 || minute_ >= 60)
        throw TimeException(TimeException::h_m_error::M);

    hour = hour_;
    minute = minute_;
}
int Time::getHour() const {
    return hour;
}
int Time::getMinute(){
   return minute;
}
TimeException::TimeException(h_m_error error, int day_)
{
    error_name = error;
    day = day_;
    if (error == h_m_error::H)
        strcpy(exp,"invalid hour");
    else if (error == h_m_error::M)
        strcpy(exp, "invalid minute");
}

const char *TimeException::what() const throw()
{
    return exp;
}
TimeException::h_m_error TimeException::error() const
{
    return error_name;
}
int TimeException::getDay() const
{
    return day;
}