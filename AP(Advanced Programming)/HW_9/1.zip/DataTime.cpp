#include "DataTime.h"
int DateTime::getYear(){
    return date->getYear();
}
int DateTime::getMonth(){
    return date->getMonth();
}
int DateTime::getDay(){
    return date->getDay();
}
int DateTime::getHour(){
    return time->getHour();
}
int DateTime::getMinute(){
    return time->getMinute();
}
DateTime::DateTime(int year, int month, int day, int hour, int minute)
{
    while (true)
    {
        try
        {
            date =new Date(year, month, day);
            time =new Time(hour, minute);
            break;
        }
        catch (int error_day)
        {
            if (error_day > 30)
                day = 30;
            else if (error_day <= 0)
                day = 1;
        }
        catch (TimeException &except)
        {
            if (except.error() == TimeException::h_m_error::M)
            {
                if (minute >= 60)
                    minute = 59;
                else if (minute < 0)
                    minute = 0;
            }
            else
                throw exception_varieble (except.what());
        }
        catch (exception &except)
        {
            throw exception_varieble(except.what());
        }
    }
}
ostream &operator<<(ostream &out,const  DateTime &obj)
{
    out << "year->" << obj.date->getYear()<< "|  Month->" << obj.date->getMonth()<< "|  Day->" << obj.date->getDay()
        << "|  Hour->" << obj.time->getHour()<< "|  Minute->" << obj.time->getMinute()<<" | "<<'\n';
    return out;
}

exception_varieble::exception_varieble(const char *error)
{
    exp = error;
}

const char *exception_varieble::what() const throw()
{
    return exp;
}