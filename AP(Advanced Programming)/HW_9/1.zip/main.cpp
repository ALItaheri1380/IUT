#include <iostream>
#include <exception>
#include "DataTime.h"
using namespace std;
int main(void)
{
    DateTime d(2002, 8, -1, 12, 70);
    cout << d;
    try
    {
        DateTime d2(-2, 10, 11, 12, 13);//inavlid y
    }
    catch(const exception& S)
    {
       cerr << S.what() << '\n';
    }

    try
    {
        DateTime d2(2022, 112, 10, 12, 1);//invalid month
        cout<<d2;
    }
    catch(const exception& S)
    {
        cerr << S.what() << '\n';
    }
    return 0;
}