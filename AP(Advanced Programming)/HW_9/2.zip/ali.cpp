#include <iostream>
#include <vector>
#include <windows.h>
#include <random>
#include <thread>
bool cheker= true;
bool cheker_2= true;
using namespace std;
vector<int> myvect(1000, 0);
vector<int> check_vect(1000 , 0);
void fix_problem(int index,int time_)
{
    cheker= false;
    Sleep(myvect[index] * time_ *1000);
    if(cheker_2== false)
    {
        myvect[index]=check_vect[index];
        check_vect[index]=0;
    } else
    {
        myvect[index] = 0;
    }
    cheker= true;
    cheker_2= true;
}
void number_for_fix_prob(int x)
{
    for (int i = 0; i < x; ++i)
    {
        cout<<"inter\n";
        int time_,index;
        cin>>time_>>index;
        fix_problem(index, time_);
    }
}
void print_vector()
{
    int i=0;
    while (i<1000)
    {
        cout<<"index is = "<<i+1<<" || "<<"the amount of this index = "<<myvect[i]<<endl;
        i++;
    }
}
void fill_node_of_vector(int index,int prob)
{
    if(cheker== false)
    {
        check_vect[index]+=prob;
        cheker_2= false;
        return;
    }
    myvect[index]+=prob;
}
void problem(int flag)
{
    for (int i = 0; i < flag; i++)
    {
        int prob = rand() % 20;
        int index = rand() % 1000;
        fill_node_of_vector(index,prob);
    }
    Sleep(1000);
}
void creat_Random_counter_of_obj(int x)
{
    for (int i = 0; i < x; ++i)
    {
        int flag = rand() % 1000;
        problem(flag);
    }
}
int main()
{
    thread th1(creat_Random_counter_of_obj,12);
    thread th2(number_for_fix_prob,3);
    th1.join();
    th2.join();
    print_vector();
    return 0;
}